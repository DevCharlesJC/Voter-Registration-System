@extends('Backend.layouts.app-master')

@section('content')
@auth
<!-- / main menu-->

<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title">{{$Pagetitle}} Forms</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Form Layouts</a>
                </li>
                <li class="breadcrumb-item active"><a href="#">{{$Pagetitle}} Forms</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->
<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form">{{$Pagetitle}} Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">	
						
						<form class="form" method="post" action="{{ route('report.index') }}">
						@csrf
							<div class="form-body">	
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label for="state">State</label>
											<input type="text" id="state" class="form-control" placeholder="Enter the State" name="state">
										</div>
									</div>

									<div class="col-md-4">
										<div class="form-group">
											<label for="district">District</label>
											<input type="text" id="district" class="form-control" placeholder="Enter the District" name="district">
										</div>
									</div>
									<div class="col-md-4">
									<div style="display: flex;justify-content: start;align-items: center;margin: 25px auto;">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Search
								</button>
							</div>
									</div>
									</div>								
							</div>

							
						</form>
					</div>
				</div>
				<div class="row match-height">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Search Voter Details</h4>
				<button onclick="ExportToExcel('xlsx')" style="background: #967adc;border: none;border-radius: 5px;float: right;margin-left: 0;margin-right: 73px;margin-top: -23px;padding: 7px 15px;color: #fff;}">Export Table Data To Excel File</button>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" id="tbl_exporttable_to_xls">
                        <thead>
                            <tr>
                                <th>#Sno</th>
								<th>UUID</th>
                                <th>Name</th>
								<th>Date of Birth</th>
								<th>District</th>
								<th>State</th>
                            </tr>
                        </thead>
                        <tbody>						
						<?php
						$i = 1;
						foreach($searchData as $Row)
						{
						?>
                            <tr>
                                <td class="text-truncate"><a href="#">{{ $i }}</a></td>
                                <td class="text-truncate">{{$Row->id}}</td>
								<td class="text-truncate">{{ucfirst($Row->firstname. ' '. $Row->lastname)}}</td>
								<td class="text-truncate">{{date("m-d-Y", strtotime($Row->dob));}}</td>
								<td class="text-truncate">{{ucfirst($Row->district)}}</td>
								<td class="text-truncate">{{ucfirst($Row->state)}}</td>
								
						<?php 
						$i++; 
						} 
						?>
                            </tr>
						
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
			</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>
<!-- ////////////////////////////////////////////////////////////////////////////-->
@endauth
@guest
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
    @endguest
    
@endsection
