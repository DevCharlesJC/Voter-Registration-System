@extends('Backend.layouts.auth-master')

@section('content')
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><section class="flexbox-container">
    <div class="col-md-4 offset-md-4 col-xs-10 offset-xs-1 box-shadow-2 p-0">
		<div class="card border-grey border-lighten-3 px-2 py-2 m-0">
			<div class="card-header no-border">
				<div class="card-title text-xs-center">
					<img src="{!! url('assets/Backend/images/logo/robust-logo-dark.png') !!}" alt="branding logo">
				</div>
				<h6 class="card-subtitle line-on-side text-muted text-xs-center font-small-3 pt-2"><span>Create Account</span></h6>
			</div>
			<div class="card-body collapse in">	
				<div class="card-block">
					<form class="form-horizontal form-simple" method="post" action="{{ route('register.perform') }}" novalidate>
					@csrf
						<fieldset class="form-group position-relative has-icon-left mb-1">
							<input type="text" class="form-control form-control-lg input-lg" id="firstname" name="firstname" value="{{ old('firstname') }}" placeholder="Enter the First Name" required="required">
							<div class="form-control-position">
							    <i class="icon-head"></i>
							</div>
							@if ($errors->has('firstname'))
								<span class="text-danger text-left">{{ $errors->first('firstname') }}</span>
							@endif
						</fieldset>
						<fieldset class="form-group position-relative has-icon-left mb-1">
							<input type="text" class="form-control form-control-lg input-lg" id="lastname" name="lastname" value="{{ old('lastname') }}" placeholder="Enter the Last Name" required="required">
							<div class="form-control-position">
							    <i class="icon-head"></i>
							</div>
							@if ($errors->has('lastname'))
								<span class="text-danger text-left">{{ $errors->first('lastname') }}</span>
							@endif
						</fieldset>
						<fieldset class="form-group position-relative has-icon-left mb-1">
							<input type="email" class="form-control form-control-lg input-lg" id="email" name="email" value="{{ old('email') }}" placeholder="name@example.com" required>
							<div class="form-control-position">
							    <i class="icon-mail6"></i>
							</div>
							@if ($errors->has('email'))
								<span class="text-danger text-left">{{ $errors->first('email') }}</span>
							@endif
						</fieldset>
						<fieldset class="form-group position-relative has-icon-left">
							<input type="password" class="form-control form-control-lg input-lg" id="password" name="password" value="{{ old('password') }}" placeholder="Enter Password" required>
							<div class="form-control-position">
							    <i class="icon-key3"></i>
							</div>
							@if ($errors->has('password'))
								<span class="text-danger text-left">{{ $errors->first('password') }}</span>
							@endif
						</fieldset>
						<fieldset class="form-group position-relative has-icon-left">
							<input type="password" class="form-control form-control-lg input-lg" id="password_confirmation" name="password_confirmation" value="{{ old('password_confirmation') }}" placeholder="Enter Confirm Password" required>
							<div class="form-control-position">
							    <i class="icon-key3"></i>
							</div>
							@if ($errors->has('password_confirmation'))
								<span class="text-danger text-left">{{ $errors->first('password_confirmation') }}</span>
							@endif
						</fieldset>
						<button type="submit" class="btn btn-primary btn-lg btn-block"><i class="icon-unlock2"></i> Register</button>
					</form>
				</div>
				<p class="text-xs-center">Already have an account ? <a href="{{ route('login.perform') }}" class="card-link">Login</a></p>
			</div>
		</div>
	</div>
</section>
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
@endsection
