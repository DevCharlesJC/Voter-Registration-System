<h1>Hi, {{ $uuid }}</h1>
<p>Sending Mail from Laravel.</p>