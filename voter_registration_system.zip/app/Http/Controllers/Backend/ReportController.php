<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;
use App\Models\Backend\Voter;

class ReportController extends Controller
{
    public function index(Request $request) 
    {
		try
		{
			$Pagetitle = "Search Report";
			$report = $request->all();
			$state = $request['state'];
			$district = $request['district'];        
			$searchData = Voter::where('state', 'LIKE', "%{$state}%")->orWhere('district', 'LIKE', "%{$district}%")->get();
			//dd($searchData);
		}
		catch (Exception $e) 
		{
			
			$message = $e->getMessage();
            var_dump('Exception Message: '. $message);
  
            $code = $e->getCode();       
            var_dump('Exception Code: '. $code);
  
            $string = $e->__toString();       
            var_dump('Exception String: '. $string);
  
            exit;
		}
        return view('Backend.report.index')->with('Pagetitle',$Pagetitle)->with('searchData',$searchData);
    }
	
}