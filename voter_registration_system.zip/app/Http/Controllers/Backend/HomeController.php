<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Backend\Voter;

class HomeController extends Controller
{
    public function index() 
    {
		try
		{
			$Pagetitle = "Home";
			$getVoters = Voter::showData();
			$todayVoters = Voter::todayData();
			$attendVoters = Voter::attendData();
			$Data = Voter::allData();
		}
		catch (Exception $e) 
		{
			
			$message = $e->getMessage();
            var_dump('Exception Message: '. $message);
  
            $code = $e->getCode();       
            var_dump('Exception Code: '. $code);
  
            $string = $e->__toString();       
            var_dump('Exception String: '. $string);
  
            exit;
		}
        return view('Backend.home.index')->with('Pagetitle',$Pagetitle)->with('getVoters',$getVoters)->with('todayVoters',$todayVoters)->with('Data',$Data)->with('attendVoters',$attendVoters);
    }
	
}