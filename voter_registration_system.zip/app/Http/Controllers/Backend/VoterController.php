<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;
use App\Models\Backend\Voter;
use Mail;
use DB;

class VoterController extends Controller
{
    public function index() 
    {
		$Pagetitle = "Voter";
        return view('Backend.voter.index')->with('Pagetitle',$Pagetitle);
    }
	
	public function postData(Request $request)
	{
		try
		{
			// Form validation
			$this->validate($request, [
				'firstname' => 'required',
				'lastname' => 'required',
				'dob' =>'required',
				'mobile' =>'required',
				'email' =>'required',
				'address' => 'required',
				'taluk' => 'required',
				'district' => 'required',
				'state' => 'required'
			 ]);
			$voter = $request->all();
			$format = str_replace("/","-",$voter['dob']);
			$voter['dob'] = date("Y-m-d", strtotime($format));
			//dd($voter['dob']);
			Voter::create($voter);
			
			$Id = DB::getPdo()->lastInsertId();
			$data_fetch_uuid = Voter::where("voter_id", $Id)->first();
			
			
			$to = $request['email'];
			$data = array('uuid'=>$data_fetch_uuid['id']);
			Mail::send(['text'=>'emails.mail'], $data, function($message) use($to) {
				 $message->to($to, 'Registration Details')->subject
					('UUID Details');
				 $message->from('charlesvictor.info@gmail.com','Voter Registration System');
			});
		}
		catch (Exception $e) 
		{
			
			$message = $e->getMessage();
            var_dump('Exception Message: '. $message);
  
            $code = $e->getCode();       
            var_dump('Exception Code: '. $code);
  
            $string = $e->__toString();       
            var_dump('Exception String: '. $string);
  
            exit;
		}
        return redirect('voter')->with('success', 'Data Submited Successfully');
		
	}
	
	public function fetchData()
	{
		$Pagetitle = "Voter";
		$Voter = Voter::showData();
        return view('Backend.voter.view')->with('Pagetitle',$Pagetitle)->with('Voter',$Voter);
	}
	
	public function deleteData($id)
    {
        $getDelete = Voter::deleteRecord($id);
        return redirect('voterShow')->with('success', 'Data deleted successfully.');
    }
}