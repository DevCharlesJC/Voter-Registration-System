<?php
namespace App\Models\Backend;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\UUID;

class Voter extends Model
{
    use HasFactory;
	
	use UUID;
	
	protected $table = 'voter';
	
	protected $fillable = [
        'firstname',
        'lastname',
        'dob',
        'mobile',
		'email',
		'address',
		'taluk',
		'district',
		'state',
		'status',
    ];
	
	public static function showData()
    {
      $value = Voter::all();
      return $value;
    }
	
	public static function attendData()
    {
      $value = Voter::where('status', 1)->get();
      return $value;
    }
	
	public static function todayData()
	{
		$value = Voter::whereDay('created_at', now()->day)->get();
		return $value;
	}
	
	public static function allData()
	{
		$value = Voter::orderBy("voter_id", "DESC")->take(10)->get();
		return $value;
	}
	
	public static function deleteRecord($id)
    {
        $value = Voter::whereId($id)->update(['status' => 1]);
        return $value;
    }
}
