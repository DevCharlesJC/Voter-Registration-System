<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/********Backend Code*********/
Route::group(['namespace' => 'App\Http\Controllers\Backend'], function()
{   
    /**
     * Voter Routes
     */
	Route::get('voter', 'VoterController@index')->name('voter.index');
	Route::get('voterShow', 'VoterController@fetchData')->name('voter.show');
	Route::post('/postData', 'VoterController@postData')->name('voter.perform');
	Route::get('deleteVoterData/{id}','VoterController@deleteData')->name('voter.deleteVoterData');
	
	Route::any('report', 'ReportController@index')->name('report.index');
	//Route::post('/reportData', 'ReportController@fetchData')->name('report.perform');
	

    Route::group(['middleware' => ['guest']], function() {
        /**
         * Register Routes
         */
        Route::get('/register', 'RegisterController@show')->name('register.show');
        Route::post('/registerData', 'RegisterController@registerData')->name('register.perform');

        /**
         * Login Routes
         */
        Route::get('/login', 'LoginController@show')->name('login.show');
        Route::post('/login', 'LoginController@login')->name('login.perform');

    });

    Route::group(['middleware' => ['auth']], function() {
		
		/**
		* Verification Routes
		*/
		Route::get('/email/verify', 'VerificationController@show')->name('verification.notice');
		Route::get('/email/verify/{id}/{hash}', 'VerificationController@verify')->name('verification.verify')->middleware(['signed']);
		Route::post('/email/resend', 'VerificationController@resend')->name('verification.resend');
        
		
		//only verified account can access with this group
		Route::group(['middleware' => ['auth','verified']], function() {
        /**
         * Home Routes
		*/
		Route::get('home', 'HomeController@index')->name('home.perform');
			
		});
		
		/**
		
		
		
		
		/**
         * Logout Routes
         */
        Route::get('/logout', 'LogoutController@perform')->name('logout.perform');
    });
});