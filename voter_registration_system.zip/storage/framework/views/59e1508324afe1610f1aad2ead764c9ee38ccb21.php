<!-- Menu -->

        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="#" class="app-brand-link">
                <img src="<?php echo url('assets/images/GsportEV_Logo.png'); ?>" width="50%" style="margin: 0 auto;"/>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item active">
              <a href="<?php echo url('/home'); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>
            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Pages</span>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div data-i18n="Careers Page">Careers Page</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="<?php echo url('postcareers'); ?>" class="menu-link">
                    <div data-i18n="Account">Add Post</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="<?php echo url('show_careers'); ?>" class="menu-link">
                    <div data-i18n="Notifications">List Post</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-lock-open-alt"></i>
                <div data-i18n="Enquiry Details">Enquiry Details</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="#" class="menu-link">
                    <div data-i18n="Basic">Contact Us</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="#" class="menu-link">
                    <div data-i18n="Basic">Booking Form</div>
                  </a>
                </li>
              </ul>
            </li>
            <!-- Misc -->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bxs-store"></i>
                <div data-i18n="Enquiry Details">Store Locators</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="<?php echo url('stores'); ?>" class="menu-link">
                    <div data-i18n="Basic">Add Store</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="<?php echo url('show_stores'); ?>" class="menu-link">
                    <div data-i18n="Basic">List Store</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-briefcase-alt-2"></i>
                <div data-i18n="Enquiry Details">Job Applied</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="<?php echo url('show_candidates'); ?>" class="menu-link">
                    <div data-i18n="Basic">View Candidates</div>
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </aside>
        <!-- / Menu -->

      <?php /**PATH C:\xampp\htdocs\gsports\resources\views/Backend/layouts/partials/navbar.blade.php ENDPATH**/ ?>