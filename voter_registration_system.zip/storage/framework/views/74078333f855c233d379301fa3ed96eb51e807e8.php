<?php $__env->startSection('content'); ?>
    
	
	<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><!-- stats -->
<div class="row">
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <?php if(session('resent')): ?>
            <div class="alert alert-success" role="alert">
                A fresh verification link has been sent to your email address.
            </div>
        <?php endif; ?>

        Before proceeding, please check your email for a verification link. If you did not receive the email,
        <form action="<?php echo e(route('verification.resend')); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <button type="submit" class="d-inline btn btn-link p-0">
                click here to request another
            </button>.
        </form>
    </div>
    
    
</div>
<!--/ stats -->
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\voter\resources\views/Backend/verification/notice.blade.php ENDPATH**/ ?>