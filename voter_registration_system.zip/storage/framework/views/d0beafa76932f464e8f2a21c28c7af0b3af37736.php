<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- / main menu-->
<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title"><?php echo e($Pagetitle); ?> Forms</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Form Layouts</a>
                </li>
                <li class="breadcrumb-item active"><a href="#"><?php echo e($Pagetitle); ?> Forms</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->
<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form"><?php echo e($Pagetitle); ?> Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">						
						<form class="form">
							<div class="form-body">	
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Category Name</label>
											<input type="text" id="projectinput4" class="form-control" placeholder="Category Name" name="category">
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Slug Name</label>
											<input type="text" id="projectinput4" class="form-control" placeholder="Slug Name" name="category">
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Language</label>
											<select id="projectinput5" name="language" class="form-control">
												<option value="" selected="" disabled="">Language</option>
												<option value="">Tamil</option>
												<option value="">English</option>
											</select>
										</div>
									</div>
								</div>
							</div>

							<div class="form-actions">
								<button type="button" class="btn btn-warning mr-1">
									<i class="icon-cross2"></i> Cancel
								</button>
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-colored-form-control">Sub Category</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">
						<form class="form">
							<div class="form-body">	
								<div class="row">
								<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Category Name</label>
											<input type="text" id="projectinput4" class="form-control" placeholder="Category Name" name="category">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Slug Name</label>
											<input type="text" id="projectinput4" class="form-control" placeholder="Slug Name" name="category">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Select Category</label>
											<select id="projectinput5" name="interested" class="form-control">
												<option value="none" selected="" disabled="">Select</option>
												<option value="design">design</option>
											</select>
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Language</label>
											<select id="projectinput6" name="language" class="form-control">
												<option value="" selected="" disabled="">Language</option>
												<option value="">Tamil</option>
												<option value="">English</option>
											</select>
										</div>
									</div>
								</div>
							</div>

							<div class="form-actions right">
								<button type="button" class="btn btn-warning mr-1">
									<i class="icon-cross2"></i> Cancel
								</button>
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gooesynewsportal\resources\views/Backend/category/index.blade.php ENDPATH**/ ?>