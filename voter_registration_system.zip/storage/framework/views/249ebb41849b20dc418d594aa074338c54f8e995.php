<!-- row 8 end -->
  <div class="blank"></div>
  <!-- FOOTER
        ================================================== -->
        <div class="ftr_top">
          <div class="container">
            <div class="makit_1">
              <p>Get in touch with us</p>
			  <a href="https://www.facebook.com/GSPORTSEV" class="widfit">
				<img src="<?php echo url('assets/images/fb.png'); ?>" alt="">
			  </a>
			  <a href="https://instagram.com/gsportsev?igshid=NjIwNzIyMDk2Mg=" class="widfit">
				<img src="<?php echo url('assets/images/insta.png'); ?>" alt="">
			  </a>
			  <a href=# class="widfit">
				<img src="<?php echo url('assets/images/twit.png'); ?>" alt="">
			  </a>
            </div>
          </div>
        </div>
       <!-- FOOTER
              ================================================== -->
              <footer class="pt-0">
                  
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-lg-3 mt-2-6">
                          <a href="<?php echo url('/'); ?>" class=" mb-1-6"><img src="<?php echo url('assets/images/logo.png'); ?>" alt="GSportsEv" class="footer-logo"></a>
                            <ul class="contact-list">
                                <li class="d-flex"><span class="fa fa-home pe-3 text-white"></span><span style="padding: 0px 10px;color: #fff;">No - 536 , Cycle world Avenue,<br> Hulimangala, Bengaluru, <br>Karnataka 560105</span></li>
                                <li class="d-flex"><span class="fa fa-phone pe-3 text-white"></span><a href="#!" style="padding: 0px 10px;">+91 7008273406</a></li>
                                <li class="d-flex"><span class="fa fa-phone pe-3 text-white"></span><a href="#!" style="padding: 0px 10px;">+91 8152908888</a></li>
                                <li class="d-flex"><span class="fa fa-envelope pe-3 text-white"></span><a href="mailto:info@gsportsbikes.com" style="padding: 0px 10px;"> ev@gsportsbikes.com</a></li>
                            </ul>
                        </div>
                        <div class="col-sm-6 col-lg-2 mt-2-6">
                            <div class="">
                                <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Information</h3>
                                <ul class="footer-list-style1">
                                    <li><a href="<?php echo url('/aboutus'); ?>">About us</a></li>
                                    <li><a href="#">Privacy &amp; Policy</a></li>
                                    <li><a href="#">Terms &amp; Conditions</a></li>
                                    <!-- <li><a href="#">Return Policy</a></li>
                                    <li><a href="#">Shipping Policy</a></li>
                                    <li><a href="#">warranty Policy</a></li> -->
                                    <li><a href="<?php echo url('/contactus'); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-2 mt-2-6">
                            <div class="ps-lg-1-9">
                                <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Quick Links</h3>
                                <ul class="footer-list-style1">
                                    <li><a href="<?php echo url('/investors'); ?>">Investors</a></li>
                                    <li><a href="<?php echo url('/franchise'); ?>">Franchise Enquiry</a></li>
                                    <li><a href="#">FAQ</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-2 mt-2-6">
                            <div class=" ps-lg-2-2 ps-xl-2-5">
                                <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Candidates</h3>
                                <ul class="footer-list-style1">
                                  <li><a href="<?php echo url('/career'); ?>">Careers</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 mt-2-6">
                            <div class="ps-lg-2-2 ps-xl-2-5">
                                <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Join Newsletter</h3>
                                <p class="text-white mb-4">Enter your email address below to subscribe to our newsletter and keep up to date with discounts and special offers.</p>
                                <form class="quform newsletter-form" action="#" method="post" enctype="multipart/form-data" onclick="">
                                    <div class="quform-elements">
                                        <div class="row">
                                            <!-- Begin Text input element -->
                                            <div class="col-md-12">
                                                <div class="quform-element">
                                                    <div class="quform-input">
                                                        <input class="form-control" id="email_address" type="text" name="email_address" placeholder="Subscribe with us">
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Text input element -->
      
                                            <!-- Begin Submit button -->
                                            <div class="col-md-12">
                                                <div class="quform-submit-inner">
                                                    <button class="btn btn-white text-primary m-0" type="submit"><span><i class="fa fa-paper-plane text-primary"></i></span></button>
                                                </div>
                                                <div class="quform-loading-wrap text-start"><span class="quform-loading"></span></div>
                                            </div>
                                            <!-- End Submit button -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bar borders-top border-color-light-white">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7 text-center text-md-start mt-3 mt-md-0 order-2 order-md-1">
                                <p class="d-inline-block text-white mb-0 cngp">© <span class="current-year"></span> GSportsEv. All rights reserved.
                                    <!-- <a href="#" target="_blank" class="text-primary white-hover">GSportsEv</a> -->
                                </p>
                            </div>
                            <!--div class="col-md-5 text-center text-md-end order-1 order-md-2 transform_itman">
                                <p class="text-white d-inline-block mb-0 align-middle cngp">Follow us on social networks :</p>
                                <ul class="footer-social-style1">
                                    <li>
                                        <a href="#!"><i class="fa fa-facebook-f"></i></a>
                                    </li>
                                    <li>
                                        <a href="#!"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="#!"><i class="fa fa-youtube"></i></a>
                                    </li>
                                    <li>
                                        <a href="#!"><i class="fa fa-linkedin"></i></a>
                                    </li>
                                </ul>
                            </div-->
                        </div>
                    </div>
                </div>
            </footer>
  <!-- Back to top button -->
<a id="button"></a><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/layouts/partials/footer.blade.php ENDPATH**/ ?>