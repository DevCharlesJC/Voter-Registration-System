<?php $__env->startSection('content'); ?>

<!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Create a Store</h4>

              <!-- Basic Layout -->
              <div class="row">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Store Details</h5>
                      <small class="text-muted float-end">Please fill all input details</small>
                    </div>
                    <div class="card-body">
					<!-- Success message -->
					<?php if(Session::has('success')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('success')); ?>

						</div>
					<?php endif; ?>
                      <form id="poststore" method="POST" action="<?php echo e(route('stores.perform')); ?>" enctype="multipart/form-data">
					  <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-fullname">Store Name</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-fullname2" class="input-group-text"
                              >
                            <i class='bx bx-briefcase-alt-2'></i>
                            </span>
                            <input
                              type="text"
                              class="form-control <?php echo e($errors->has('store_name') ? 'error' : ''); ?>"
                              id="basic-icon-default-fullname"
                              placeholder="Store Name"
                              aria-label="Store Name"
                              aria-describedby="basic-icon-default-fullname2"
							  name="store_name"
                            />
							<!-- Error -->
							<?php if($errors->has('store_name')): ?>
							<div class="error">
								<?php echo e($errors->first('store_name')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Store Address</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-message2" class="input-group-text"
                              ><i class="bx bx-detail"></i
                            ></span>
                            <textarea
                              id="basic-icon-default-message"
                              class="form-control <?php echo e($errors->has('address') ? 'error' : ''); ?>"
                              placeholder="Enter the Address"
                              aria-label="Enter the Address"
                              aria-describedby="basic-icon-default-message2"
							  name="address"
                            ></textarea>
							<!-- Error -->
							<?php if($errors->has('address')): ?>
							<div class="error">
								<?php echo e($errors->first('address')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-phone">City</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-phone2" class="input-group-text"
                              ><i class="bx bx-money"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-phone"
                              class="form-control phone-mask <?php echo e($errors->has('city') ? 'error' : ''); ?>"
                              placeholder="Enter the City"
                              aria-label="Enter the City"
                              aria-describedby="basic-icon-default-phone2"
							  name="city"
                            />
							<!-- Error -->
							<?php if($errors->has('city')): ?>
							<div class="error">
								<?php echo e($errors->first('city')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-message">State</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-message2" class="input-group-text"
                              ><i class="bx bx-detail"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-phone"
                              class="form-control phone-mask <?php echo e($errors->has('state') ? 'error' : ''); ?>"
                              placeholder="Enter the State"
                              aria-label="Enter the State"
                              aria-describedby="basic-icon-default-phone2"
							  name="state"
                            />
							<!-- Error -->
							<?php if($errors->has('state')): ?>
							<div class="error">
								<?php echo e($errors->first('state')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                    
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-email">Email</label>
                          <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                            <input
                              type="text"
                              id="basic-icon-default-email"
                              class="form-control <?php echo e($errors->has('email') ? 'error' : ''); ?>"
                              placeholder="Enter the Email Address"
                              aria-label="Enter the Email Address"
                              aria-describedby="basic-icon-default-email2"
							  name="email"
                            />
                            <!-- Error -->
							<?php if($errors->has('email')): ?>
							<div class="error">
								<?php echo e($errors->first('email')); ?>

							</div>
							<?php endif; ?>
                          </div>
                          <div class="form-text">You can use letters, numbers & periods</div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-phone">Phone No</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-phone2" class="input-group-text"
                              ><i class="bx bx-phone"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-phone"
                              class="form-control phone-mask <?php echo e($errors->has('phoneno') ? 'error' : ''); ?>"
                              placeholder="Enter the Phone Number"
                              aria-label="Enter the Phone Number"
                              aria-describedby="basic-icon-default-phone2"
							  name="phoneno" maxlength="10"
                            />
							<!-- Error -->
							<?php if($errors->has('phoneno')): ?>
							<div class="error">
								<?php echo e($errors->first('phoneno')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Google Map</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              >
                            <i class='bx bxl-location'></i></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('gmap') ? 'error' : ''); ?>"
                              placeholder="Enter the Google Map Link"
                              aria-label="Enter the Google Map Link"
                              aria-describedby="basic-icon-default-company2"
							  name="gmap"
                            />
							<!-- Error -->
							<?php if($errors->has('gmap')): ?>
							<div class="error">
								<?php echo e($errors->first('gmap')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
						<div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Store Image</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              >
                            <i class='bx bxl-location'></i></span>
                            <input
                              type="file"
                              class="form-control <?php echo e($errors->has('store_image') ? 'error' : ''); ?>"
							  name="store_image"
                            />
							<!-- Error -->
							<?php if($errors->has('store_image')): ?>
							<div class="error">
								<?php echo e($errors->first('store_image')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                      </form>
					  </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Backend/stores/index.blade.php ENDPATH**/ ?>