<!-- main menu-->
    <div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
      <!-- main menu header-->
      <div class="main-menu-header">
        <input type="text" placeholder="Search" class="menu-search form-control round"/>
      </div>
      <!-- / main menu header-->
      <!-- main menu content-->
      <div class="main-menu-content">
        <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
          <li class=" nav-item"><a href="#"><i class="icon-home3"></i><span data-i18n="nav.dash.main" class="menu-title">Main</span></a>
            <ul class="menu-content">
              <li class="<?php //echo $activeHome; ?>"><a href="<?php echo e(route('home.perform')); ?>" data-i18n="nav.dash.main" class="menu-item"><?php echo e(config('global.dashboard')); ?></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title"><?php echo e(config('global.category')); ?></span></a>
            <ul class="menu-content">
              <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('category.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.addcategory')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('category.show')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.viewcategory')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('subcategory.show')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.subcategory')); ?></a>
              </li>
            </ul>
          </li>
		  <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title"><?php echo e(config('global.posts')); ?></span></a>
            <ul class="menu-content">
              <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('posts.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.addposts')); ?></a>
              </li>
            </ul>
          </li>
		  <li class=" nav-item"><a href="<?php echo e(route('seo.perform')); ?>"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title"><?php echo e(config('global.seo')); ?></span></a>
          </li>
		  <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title"><?php echo e(config('global.settings')); ?></span></a>
            <ul class="menu-content">
              <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('general.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.general_settings')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('posts.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.contact_information')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('social.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.social_media')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('cookies.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.cookie_warnings')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('posts.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.cms')); ?></a>
              </li>
			  <li class="<?php //echo $activeCategory; ?>"><a href="<?php echo e(route('posts.perform')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item"><?php echo e(config('global.ads_management')); ?></a>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div><?php /**PATH C:\xampp\htdocs\gooesynewsportal\resources\views/Backend/layouts/partials/navbar.blade.php ENDPATH**/ ?>