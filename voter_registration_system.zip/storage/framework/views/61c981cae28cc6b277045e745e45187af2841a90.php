
<?php $__env->startSection('content'); ?>
<div class="abtrow2">
    <div class="container">
        <p>Our mission is to provide our customers with high-quality, innovative electric scooters<br> that promote a healthy, active lifestyle while also being environmentally conscious.</p>
    </div>
  </div>
<div class="aboutusctr">
    <div class="row">
        <div class="col-md-5 p-0">
            <img src="<?php echo url('assets/images/our-journeylft.jpg'); ?>" alt="">
        </div>
        <div class="col-md-7 oj_right">
            <div class="row oj_rightinr">
                <div class="col-md-4">
                    <img src="<?php echo url('assets/images/ojlogo.png'); ?>" alt="">
                </div>
                <div class="col-md-8 expn">
                    <ul class="experiences">

                        <!-- Experience -->
                        <li class="green">
                          <div class="where">2011-Started CYCLE WORLD bicycle retail store by Mr. & Mrs. krishnasamy Devaraj, with 2 employees, Bengaluru,</div>
                         </li>
                        <li class="green">
                          <div class="where">2019-Registered as Team Cycle World pvt Ltd</div>
                         </li>
                        <li class="green">
                          <div class="where">2019-G-SPORTS BIKES (Bicycle Brand) Launched to cater Mid Premium customers</div>
                         </li>
                         <li class="green">
                            <div class="where">2022-Honoured Most Trusted and Fastest Growing Bicycle Franchise Brand Award by Times Group.</div>
                           </li>
                          <li class="green">
                            <div class="where">2022-G-SPORTS EV project initiated</div>
                           </li>
						   <li class="green">
                            <div class="where">2023-Bicycle Manufacturing Unit started with the capacity of manufacturing 6000 cycles per month in Bengaluru.</div>
                           </li>
						   <li class="green">
                            <div class="where">2023-Grown to India's Largest Multibrand Bicycles chain with 80+ retail stores and 400+ staffs.</div>
                           </li>
						   <li class="green">
                            <div class="where">2023-First Prototype Launched for G SPORTS EV.</div>
                           </li>
                      </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="abtrow3">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo url('assets/images/whatweareimg.jpg'); ?>" alt="">
            </div>
            <div class="col-md-6 abtinrht">
                <h2>What <span style="color: #000;">We Are?</span></h2>
                <ul style="padding-left: 20px;">
                    <li>Team Cycle World is the leading Bicycle Retail chain in India. Having Bicycles and components manufacturing facility in Bengaluru to cater inhouse requirements.</li>
                    <li>We represent 15+ National & International Brands, as like Croma, Reliance Digital for Electronics, Team Cycle World is for Bicycles.</li>
                    <li>Entering into 2-wheeler EV manufacturing.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="ourproduct">
    <div class="container">
        <h2>Brands</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="half_card">
                    <h4>BICYCLES</h4>
                    <p>Achieved #1 position in bicycles retail industry<br> with 15+ brands and 80 stores.<br> 
                        G SPORTS having 40% of the contribution on<br> over all sales.</p>
                    <img src="<?php echo url('assets/images/gsport_cycle.png'); ?>" alt="">
                </div>
            </div>
            <div class="col-md-6">
                <div class="half_card">
                    <h4>ELECTRIC VEHICLES</h4>
                    <p>To cater India’s demand of quality Electric <br>vehicle requirements with 85% indigenous<br> component.</p>
                    <img src="<?php echo url('assets/images/gsport_scooty.png'); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="factoty-overview">
    <div class="container">
        <div class="row">
            <div class="col-md-6 facspc ">
                <h2>Factory Overview</h2>
                <div class=" makitcntr">
                    <div class="icon_img">
                        <img src="<?php echo url('assets/images/fi_1.png'); ?>" alt="">
                    </div>
                    <div class="txt_lnd">
                        <p>4 Acres of Land in Hosur to Rayakotta Road</p>
                    </div>
                </div>
                <div class=" makitcntr">
                    <div class="icon_img">
                        <img src="<?php echo url('assets/images/fi_2.png'); ?>" alt="">
                    </div>
                    <div class="txt_lnd">
                        <p>Hosur is Two-wheeler manufacturing Hub, many ancillary units around Hosur to support TVS, Ather, OLA and Simple Energy.</p>
                    </div>
                </div>
                <div class=" makitcntr">
                    <div class="icon_img">
                        <img src="<?php echo url('assets/images/fi_3.png'); ?>" alt="">
                    </div>
                    <div class="txt_lnd">
                        <p>500-meter access to highways</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 p-0">
                <img src="<?php echo url('assets/images/factory_land.png'); ?>" alt="" width="100%">
            </div>
        </div>
    </div>
</div>
<div class="abtrow4">
    <div class="container">
        <div class="row">
            <div class="col-md-8 abtinrht1">
                <h2>Why <span style="color: #000;">E-Scooter</span></h2>
                <img src="<?php echo url('assets/images/pricebike.png'); ?>" alt="" class="imgmob">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card abtcard">
                            <h1>01</h1>
                            <p>Market demand is 5 Mn E2W-Vehicle in next 3 Years.</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card abtcard">
                            <h1>02</h1>
                            <p>Working with Tier 1 suppliers for all components for Motor/ Cell/Controller/BMS and in house battery pack.</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card abtcard">
                            <h1>03</h1>
                            <p>Planning to sell G SPORTS EV through our existing/ upcoming retail showrooms and Online.</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card abtcard">
                            <h1>04</h1>
                            <p>Setting up a data center to monitor scooters with live data and prevents EV failures for customers.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <img src="<?php echo url('assets/images/pricebike.png'); ?>" alt="" class="imgdesk">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.about_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/about.blade.php ENDPATH**/ ?>