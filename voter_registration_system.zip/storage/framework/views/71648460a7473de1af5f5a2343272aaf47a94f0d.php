<?php $__env->startSection('content'); ?>

<!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Create a Job</h4>

              <!-- Basic Layout -->
              <div class="row">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Job Details</h5>
                      <small class="text-muted float-end">Please fill all input details</small>
                    </div>
                    <div class="card-body">
					<!-- Success message -->
					<?php if(Session::has('success')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('success')); ?>

						</div>
					<?php endif; ?>
                      <form id="postjob" method="POST" action="<?php echo e(route('pcareers.perform')); ?>" enctype="multipart/form-data">
					  <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-fullname">Job Position</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-fullname2" class="input-group-text"
                              >
                            <i class='bx bx-briefcase-alt-2'></i>
                            </span>
                            <input
                              type="text"
                              class="form-control <?php echo e($errors->has('jobposition') ? 'error' : ''); ?>"
                              id="basic-icon-default-fullname"
                              placeholder="Job Position"
                              aria-label="Job Position"
                              aria-describedby="basic-icon-default-fullname2"
							  name="jobposition"
                            />
							<!-- Error -->
							<?php if($errors->has('jobposition')): ?>
							<div class="error">
								<?php echo e($errors->first('jobposition')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Carrer Level</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              ><i class="bx bx-file"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('careerlevel') ? 'error' : ''); ?>"
                              placeholder="ACME Inc."
                              aria-label="ACME Inc."
                              aria-describedby="basic-icon-default-company2"
							  name="careerlevel"
                            />
							<!-- Error -->
							<?php if($errors->has('careerlevel')): ?>
							<div class="error">
								<?php echo e($errors->first('careerlevel')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-phone">Salary</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-phone2" class="input-group-text"
                              ><i class="bx bx-money"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-phone"
                              class="form-control phone-mask <?php echo e($errors->has('salary') ? 'error' : ''); ?>"
                              placeholder="xxx xxx xxx"
                              aria-label="xxx xxx xxx"
                              aria-describedby="basic-icon-default-phone2"
							  name="salary"
                            />
							<!-- Error -->
							<?php if($errors->has('salary')): ?>
							<div class="error">
								<?php echo e($errors->first('salary')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-message">Job Description</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-message2" class="input-group-text"
                              ><i class="bx bx-detail"></i
                            ></span>
                            <textarea
                              id="basic-icon-default-message"
                              class="form-control <?php echo e($errors->has('jobdescription') ? 'error' : ''); ?>"
                              placeholder="Enter the Job Description"
                              aria-label="Enter the Job Description"
                              aria-describedby="basic-icon-default-message2"
							  name="jobdescription"
                            ></textarea>
							<!-- Error -->
							<?php if($errors->has('jobdescription')): ?>
							<div class="error">
								<?php echo e($errors->first('jobdescription')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-message">Technical Skills</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-message2" class="input-group-text"
                              ><i class="bx bx-detail"></i
                            ></span>
                            <textarea
                              id="basic-icon-default-message"
                              class="form-control <?php echo e($errors->has('technicalskills') ? 'error' : ''); ?>"
                              placeholder="Enter the Technical Skills"
                              aria-label="Enter the Technical Skills"
                              aria-describedby="basic-icon-default-message2"
							  name="technicalskills"
                            ></textarea>
							<!-- Error -->
							<?php if($errors->has('technicalskills')): ?>
							<div class="error">
								<?php echo e($errors->first('technicalskills')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                    </div>
                  </div>
                  <div class="card mb-4">
                      <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Company Details</h5>
                      <small class="text-muted float-end">Please fill all input details</small>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Company Name</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              ><i class="bx bx-buildings"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('companyname') ? 'error' : ''); ?>"
                              placeholder="GSports Inc."
                              aria-label="GSports Inc."
                              aria-describedby="basic-icon-default-company2"
							  name="companyname"
                            />
							<!-- Error -->
							<?php if($errors->has('companyname')): ?>
							<div class="error">
								<?php echo e($errors->first('companyname')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-email">Email</label>
                          <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                            <input
                              type="text"
                              id="basic-icon-default-email"
                              class="form-control <?php echo e($errors->has('email') ? 'error' : ''); ?>"
                              placeholder="john.doe"
                              aria-label="john.doe"
                              aria-describedby="basic-icon-default-email2"
							  name="email"
                            />
                            <span id="basic-icon-default-email2" class="input-group-text">@example.com</span>
							<!-- Error -->
							<?php if($errors->has('email')): ?>
							<div class="error">
								<?php echo e($errors->first('email')); ?>

							</div>
							<?php endif; ?>
                          </div>
                          <div class="form-text">You can use letters, numbers & periods</div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-phone">Phone No</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-phone2" class="input-group-text"
                              ><i class="bx bx-phone"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-phone"
                              class="form-control phone-mask <?php echo e($errors->has('phoneno') ? 'error' : ''); ?>"
                              placeholder="658 799 8941"
                              aria-label="658 799 8941"
                              aria-describedby="basic-icon-default-phone2"
							  name="phoneno" maxlength="10"
                            />
							<!-- Error -->
							<?php if($errors->has('phoneno')): ?>
							<div class="error">
								<?php echo e($errors->first('phoneno')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">LinkedIn</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              >
                            <i class='bx bxl-linkedin'></i></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('linkedin') ? 'error' : ''); ?>"
                              placeholder="LinkedIn"
                              aria-label="LinkedIn"
                              aria-describedby="basic-icon-default-company2"
							  name="linkedin"
                            />
							<!-- Error -->
							<?php if($errors->has('linkedin')): ?>
							<div class="error">
								<?php echo e($errors->first('linkedin')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Instagram</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              ><i class="bx bxl-instagram"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('instagram') ? 'error' : ''); ?>"
                              placeholder="Instagram"
                              aria-label="Instagram"
                              aria-describedby="basic-icon-default-company2"
							  name="instagram"
                            />
							<!-- Error -->
							<?php if($errors->has('instagram')): ?>
							<div class="error">
								<?php echo e($errors->first('instagram')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Facebook</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              ><i class="bx bxl-facebook"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('facebook') ? 'error' : ''); ?>"
                              placeholder="Facebook"
                              aria-label="Facebook"
                              aria-describedby="basic-icon-default-company2"
							  name="facebook"
                            />
							<!-- Error -->
							<?php if($errors->has('facebook')): ?>
							<div class="error">
								<?php echo e($errors->first('facebook')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-icon-default-company">Twitter</label>
                          <div class="input-group input-group-merge">
                            <span id="basic-icon-default-company2" class="input-group-text"
                              ><i class="bx bxl-twitter"></i
                            ></span>
                            <input
                              type="text"
                              id="basic-icon-default-company"
                              class="form-control <?php echo e($errors->has('twitter') ? 'error' : ''); ?>"
                              placeholder="Twitter"
                              aria-label="Twitter"
                              aria-describedby="basic-icon-default-company2"
							  name="twitter"
                            />
							<!-- Error -->
							<?php if($errors->has('twitter')): ?>
							<div class="error">
								<?php echo e($errors->first('twitter')); ?>

							</div>
							<?php endif; ?>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Backend/pcareers/index.blade.php ENDPATH**/ ?>