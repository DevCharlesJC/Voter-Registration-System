<script src="<?php echo url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo url('assets/js/jquery.slim.min.js'); ?>"></script>
<script src="<?php echo url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo url('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo url('assets/js/jquery.min.loader.js'); ?>"></script>
<script  src="<?php echo url('assets/js/script.js'); ?>"></script>
<script src="<?php echo url('assets/js/360ImageRotate.min.js'); ?>"></script><?php /**PATH C:\xampp\htdocs\gooesynewsportal\resources\views/Frontend/layouts/partials/scripts.blade.php ENDPATH**/ ?>