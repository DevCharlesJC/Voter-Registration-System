
<?php $__env->startSection('content'); ?>
<!-- row 1 end -->
  <section class="pdtop">
    <div class="container">
        <div class="row mb-2-5 mb-lg-2-9">
            <div class="col-lg-12">
                <div class="p-1-6 p-md-1-9 border border-color-extra-light-gray border-radius-10">
                    <div class="row align-items-center">
                        <div class="col-lg-9 mb-4 mb-lg-0">
                            <div class="d-lg-flex align-items-center text-center text-lg-start">
                                
                                <div class="flex-grow-1 ">
                                    <h4 class="mb-3">Assistant Manager<span class="job-detail-info"><i class="ti-briefcase text-primary pe-2"></i>Full Time</span></h4>
                                    <span class="me-2"><i class="ti-briefcase pe-2 text-secondary"></i>Finance Agency</span>
                                    <span class="me-2"><i class="ti-location-pin pe-2 text-secondary"></i>Canada</span>
                                    <span class="me-2"><i class="ti-time pe-2 text-secondary"></i>5 Year</span>
                                    <span><i class="far fa-money-bill-alt pe-2 text-secondary"></i>$25K</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="row">
                                <div class="text-center mb-3">Application Ends: <strong>Nov 28, 2021</strong></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-2-2 mb-lg-2-5   border-color-extra-light-gray">
            <div class="col-lg-8 mb-2-2 mb-lg-0">
                <div class="pe-lg-1-6 pe-xl-1-9">
                    <div class="row">
                        <div class="col-lg-12 mb-2-2">
                            <div class="p-1-6 border border-color-extra-light-gray border-radius-10">
                                <h4 class="mb-3">Job Details :</h4>
                                <div class="row mt-n3">
                                    <div class="col-sm-6 col-md-4 mt-3">
                                        <div class="border border-color-extra-light-gray py-3 px-4 border-radius-10">
                                            <h5 class="display-29 display-xl-28">Offered Salary</h5>
                                            <span class="font-weight-500 text-primary display-30">$25K</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-4 mt-3">
                                        <div class="border border-color-extra-light-gray py-3 px-4 border-radius-10">
                                            <h5 class="display-29 display-xl-28">Career Level</h5>
                                            <span class="font-weight-500 text-primary display-30">Executive</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-4 mt-3">
                                        <div class="border border-color-extra-light-gray py-3 px-4 border-radius-10">
                                            <h5 class="display-29 display-xl-28">Experience</h5>
                                            <span class="font-weight-500 text-primary display-30">5 Years</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-4 mt-3">
                                        <div class="border border-color-extra-light-gray py-3 px-4 border-radius-10">
                                            <h5 class="display-29 display-xl-28">Gender</h5>
                                            <span class="font-weight-500 text-primary display-30">Male</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-4 mt-3">
                                        <div class="border border-color-extra-light-gray py-3 px-4 border-radius-10">
                                            <h5 class="display-29 display-xl-28">Industry</h5>
                                            <span class="font-weight-500 text-primary display-30">Finance Agency</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-4 mt-3">
                                        <div class="border border-color-extra-light-gray py-3 px-4 border-radius-10">
                                            <h5 class="display-29 display-xl-28">Qualification</h5>
                                            <span class="font-weight-500 text-primary display-30">Master</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-2-2">
                            <div class="p-1-6 border border-color-extra-light-gray border-radius-10">
                                <h4 class="mb-3">Job Description :</h4>
                                <p>A good job description begins offevolved with an eye-catching precis of the location and its position inside your organisation. Your precis must offer an outline of your organisation and expectancies for the location. Outline the sorts of sports and duties required for the job so job seekers can decide if they're qualified, or if the job is appropriate for them.</p>
                                <p class="mb-0">If you like to work in a fast paced retail surroundings and preference an possibility to earn appealing bonuses in your difficult paintings, we need to pay attention from you. Our shoe shop franchise wishes an articulate and informed person to take over the Assistant Manager role. You’ll set schedules for all income associates, assist the GM increase and control promotions, make contributions to the high-power surroundings withinside the shop, order products and take care of all budgetary elements of walking the business. We sell from inside each time possible, so capability profession tracks should encompass GM, DM or advertising prospects.</p>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-2-2">
                            <div class="p-1-6 border border-color-extra-light-gray border-radius-10">
                                <h4 class="mb-3">Key Responsibilities :</h4>
                                <ul class="list-unstyled mb-0">
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Hire and teach sales associates to work at the ground in addition to in shipping.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Allow your information of rising and steady traits to tell buying and stock selections and solutions.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Continually advance your product understanding and that of different employees.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Maintain correct purchaser facts for loyalty program.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Manage and examine sales and cost reports.</li>
                                    <li class="d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Become liaison with company workplace and use contacts to sell the commercial enterprise and align with emblem values.</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-2-2">
                            <div class="p-1-6 border border-color-extra-light-gray border-radius-10">
                                <h5 class="mb-3">Skill & Experience :</h5>
                                <ul class="list-unstyled mb-0">
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>2+ years retail revel in in a management capacity.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Bachelor’s diploma or equal experience.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Ability to efficiently teach and inspire income associates.</li>
                                    <li class="mb-3 d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Willingness to expose management and steerage from the floor.</li>
                                    <li class="d-flex align-items-baseline"><i class="fas fa-check text-primary me-2 vertical-align-middle"></i>Familiarity with style tendencies and styles.</li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="job-details-sidebar">
                    <div class="widget">
                        <div class="card border border-color-extra-light-gray border-radius-10">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center mb-1-9">
                                    <div class="flex-grow-1 ">
                                        <h5 class="mb-1">GSports Ev</h5>
                                        <a href="#!" class="font-weight-600">View Company Profile</a>
                                    </div>
                                </div>
                                <ul class="list-style5">
                                    <li><span>Industry</span>GSports Ev</li>
                                    <li><span>Phone</span> +91 87490 00087</li>
                                    <li><span>Website</span>https://gsportsev.com/</li>
                                    <li><span>Address</span> No - 536 cycle world Avenue, Hulimangala, Bengaluru, Karnataka 560105</li>
                                    <li>
                                        <span>Follow</span>
                                        <div class="social-links">
                                            <a href="#!"><i class="fab fa-facebook-f"></i></a>
                                            <a href="#!"><i class="fab fa-twitter"></i></a>
                                            <a href="#!"><i class="fab fa-instagram"></i></a>
                                            <a href="#!"><i class="fab fa-linkedin-in"></i></a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="card border border-color-extra-light-gray border-radius-10">
                            <div class="card-body p-4">
                                <h4>Location</h4>
                                <iframe class="map-h250" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d972.5832801508759!2d77.64147866963086!3d12.821737506882302!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae6b503b7490e3%3A0x7c3b260e04bb4541!2sTeam%20Cycle%20World!5e0!3m2!1sen!2sin!4v1685010931431!5m2!1sen!2sin"></iframe>
                                
                            </div>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="card border border-color-extra-light-gray border-radius-10">
                            <div class="card-body p-4">
                                <h4>Apply For This Job </h4>
                                <form class="contact quform" action="" method="post" enctype="multipart/form-data">
                                    <div class="quform-elements">
                                        <div class="row">

                                            <!-- Begin Text input element -->
                                            <div class="col-md-6">
                                                <div class="quform-element form-group">
                                                    <label for="name">Your Name <span class="quform-required">*</span></label>
                                                    <div class="quform-input">
                                                        <input class="form-control border-radius-10" id="name" type="text" name="name" placeholder="Your name here" />
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Text input element -->

                                            <!-- Begin Text input element -->
                                            <div class="col-md-6">
                                                <div class="quform-element form-group">
                                                    <label for="email">Your Email <span class="quform-required">*</span></label>
                                                    <div class="quform-input">
                                                        <input class="form-control border-radius-10" id="email" type="text" name="email" placeholder="Your email here" />
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Text input element -->

                                            <!-- Begin Text input element -->
                                            <div class="col-md-6">
                                                <div class="quform-element form-group">
                                                    <label for="subject">Your Subject <span class="quform-required">*</span></label>
                                                    <div class="quform-input">
                                                        <input class="form-control border-radius-10" id="subject" type="text" name="subject" placeholder="Your subject here" />
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Text input element -->

                                            <!-- Begin Text input element -->
                                            <div class="col-md-6">
                                                <div class="quform-element form-group">
                                                    <label for="phone">Contact Number</label>
                                                    <div class="quform-input">
                                                        <input class="form-control border-radius-10" id="phone" type="text" name="phone" placeholder="Your phone here" />
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Text input element -->

                                            <!-- Begin Textarea element -->
                                            <div class="col-md-12">
                                                <div class="quform-element form-group">
                                                    <label for="message">Message <span class="quform-required">*</span></label>
                                                    <div class="quform-input">
                                                        <textarea class="form-control border-radius-10" id="message" name="message" rows="3" placeholder="Tell us a few words"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                              <div class="quform-element form-group">
                                                  <label for="message">Upload Resume <span class="quform-required">*</span></label>
                                                  <div class="quform-input">
                                                    <input type="file" id="myFile" name="filename">
                                                  </div>
                                              </div>
                                          </div>
                                            <!-- End Textarea element -->

                                           

                                            <!-- Begin Submit button -->
                                            <div class="col-md-12">
                                                <div class="quform-submit-inner">
                                                    <button class="butn border-0" type="submit"><span>Submit to apply</span></button>
                                                </div>
                                            </div>
                                            <!-- End Submit button -->

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
  <!-- row 8 end -->
  <div class="blank"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.career_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/career_details.blade.php ENDPATH**/ ?>