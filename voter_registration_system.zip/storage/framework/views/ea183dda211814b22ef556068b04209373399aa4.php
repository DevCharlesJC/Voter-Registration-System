<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- / main menu-->
<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title"><?php echo e($Pagetitle); ?> Forms</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Form Layouts</a>
                </li>
                <li class="breadcrumb-item active"><a href="#"><?php echo e($Pagetitle); ?> Forms</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic table layout section start -->
<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-xs-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form"><?php echo e($Pagetitle); ?> Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<!-- Success message -->
					<?php if(Session::has('success')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('success')); ?>

						</div>
					<?php endif; ?>
				<div class="card-body collapse in">
                <div class="card-block card-dashboard">
                    <p>List of Voter Details</p>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#Sno</th>
									<th>UUID</th>
									<th>Name</th>
									<th>Date of Birth</th>
									<th>District</th>
									<th>State</th>
									<th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
							<?php
							$i=1;
							foreach($Voter as $Row)
							{
								if($Row->status == 0)
								{
							?>
                                <tr>
                                    <td class="text-truncate"><a href="#"><?php echo e($i); ?></a></td>
									<td class="text-truncate"><?php echo e($Row->id); ?></td>
									<td class="text-truncate"><?php echo e(ucfirst($Row->firstname. ' '. $Row->lastname)); ?></td>
									<td class="text-truncate"><?php echo e(date("m-d-Y", strtotime($Row->dob))); ?></td>
									<td class="text-truncate"><?php echo e(ucfirst($Row->district)); ?></td>
									<td class="text-truncate"><?php echo e(ucfirst($Row->state)); ?></td>
                                    <td><a href="deleteVoterData/<?php echo e($Row->id); ?>">Delete</a></td>
							<?php 
							$i++;
								}							
							} 
							?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
			</div>
		</div>
	</div>
</section>
<!-- // Basic table layout section end -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\voter\resources\views/Backend/voter/view.blade.php ENDPATH**/ ?>