<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- / main menu-->
<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title"><?php echo e($Pagetitle); ?> Forms</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Form Layouts</a>
                </li>
                <li class="breadcrumb-item active"><a href="#"><?php echo e($Pagetitle); ?> Forms</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->
<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form"><?php echo e($Pagetitle); ?> Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">						
						<form class="form">
							<div class="form-body">
								<h4 class="form-section"><i class="icon-head"></i> Personal Info</h4>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="title_name">Title</label>
											<input type="text" id="title_name" class="form-control" placeholder="Enter the Title" name="title_name">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="slug_name">Slug Name</label>
											<input type="text" id="slug_name" class="form-control" placeholder="Enter the Slug Name" name="slug_name">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<label for="short_description">Short Description</label>
											<div class="position-relative has-icon-left">
										<textarea id="short_description" rows="5" class="form-control" name="short_description" placeholder="Enter the Short Description"></textarea>
										<div class="form-control-position">
											<i class="icon-file2"></i>
										</div>
									</div>
										</div>
									</div>
								</div>

								<h4 class="form-section"><i class="icon-clipboard4"></i> Requirements</h4>

								<div class="form-group">
									<label for="keywords">Keywords</label>
									<input type="text" id="keywords" class="form-control" placeholder="Enter the Keywords" name="keywords">
								</div>
								
								<div class="form-group">
									<label>Visibility</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="visibility" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="visibility" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label>Add to Featured</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="featured" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="featured" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label>Add on Headline</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="headline" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="headline" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label>Add to Breaking</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="breaking" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="breaking" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label>Add to Slider</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="slider" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="slider" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label>Add to Recommended</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="recommended" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="recommended" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label>Show Only to Registered Users</label>
									<div class="input-group">
										<label class="display-inline-block custom-control custom-radio ml-1">
											<input type="radio" name="featured" class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">Yes</span>
										</label>
										<label class="display-inline-block custom-control custom-radio">
											<input type="radio" name="featured" checked class="custom-control-input">
											<span class="custom-control-indicator"></span>
											<span class="custom-control-description ml-0">No</span>
										</label>
									</div>
								</div>
								
								<div class="form-group">
									<label for="tag">Tag</label>
									<input type="text" id="tag" class="form-control" placeholder="Enter the Tag" name="tag">
								</div>
								
								<div class="form-group">
									<label for="optional_url">Optional URL</label>
									<input type="text" id="optional_url" class="form-control" placeholder="Enter the Optional URL" name="optional_url">
								</div>
								
								<div class="form-group">
									<div class="position-relative has-icon-left">
										<textarea id="timesheetinput7" rows="5" class="form-control" name="notes" placeholder="notes"></textarea>
										<div class="form-control-position">
											<i class="icon-file2"></i>
										</div>
									</div>
								</div>
								<h4 class="form-section"><i class="icon-clipboard4"></i> Publish Post Details</h4>
								<div class="col-md-6">
										<div class="form-group">
											<label for="issueinput3">Scheduled Post</label>
											<input type="date" id="issueinput3" class="form-control" name="dateopened" data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="Date Opened">
										</div>
									</div>
							</div>

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Publish
								</button>
								<button type="submit" class="btn btn-warning mr-1">
									<i class="icon-cross2"></i> Save as Draft
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gooesynewsportal\resources\views/Backend/posts/index.blade.php ENDPATH**/ ?>