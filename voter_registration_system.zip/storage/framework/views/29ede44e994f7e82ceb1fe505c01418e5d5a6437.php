
<?php $__env->startSection('content'); ?>
<!-- MAP
        ================================================== -->
       

        <!-- CONTACT FORM
        ================================================== -->
        <section class=" padding_tb">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 mb-2-2 mb-lg-0">
                        <div class="p-1-6 p-sm-1-9 p-lg-2-2 border border-radius-10 border-color-extra-light-gray bg-white h-100">
                            <h2 class="h3 mb-2-5 text-center text-capitalize">Contact Us</h2>
                            <form class="contact quform" action="https://jobboard.websitelayout.net/quform/contact.php" method="post" enctype="multipart/form-data" onclick="">
                                <div class="quform-elements">
                                    <div class="row">

                                        <!-- Begin Text input element -->
                                        <div class="col-md-6">
                                            <div class="quform-element form-group">
                                                <label for="name">Your Name <span class="quform-required">*</span></label>
                                                <div class="quform-input">
                                                    <input class="form-control border-radius-10" id="name" type="text" name="name" placeholder="Your name here" />
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Text input element -->

                                        <!-- Begin Text input element -->
                                        <div class="col-md-6">
                                            <div class="quform-element form-group">
                                                <label for="email">Your Email <span class="quform-required">*</span></label>
                                                <div class="quform-input">
                                                    <input class="form-control border-radius-10" id="email" type="text" name="email" placeholder="Your email here" />
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Text input element -->

                                        <!-- Begin Text input element -->
                                        <div class="col-md-6">
                                            <div class="quform-element form-group">
                                                <label for="subject">Your Subject <span class="quform-required">*</span></label>
                                                <div class="quform-input">
                                                    <input class="form-control border-radius-10" id="subject" type="text" name="subject" placeholder="Your subject here" />
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Text input element -->

                                        <!-- Begin Text input element -->
                                        <div class="col-md-6">
                                            <div class="quform-element form-group">
                                                <label for="phone">Contact Number</label>
                                                <div class="quform-input">
                                                    <input class="form-control border-radius-10" id="phone" type="text" name="phone" placeholder="Your phone here" />
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Text input element -->

                                        <!-- Begin Textarea element -->
                                        <div class="col-md-12">
                                            <div class="quform-element form-group">
                                                <label for="message">Message <span class="quform-required">*</span></label>
                                                <div class="quform-input">
                                                    <textarea class="form-control border-radius-10" id="message" name="message" rows="3" placeholder="Tell us a few words"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Textarea element -->

                                        

                                        <!-- Begin Submit button -->
                                        <div class="col-md-12">
                                            <div class="quform-submit-inner">
                                                <button class="butn border-0" type="submit"><span>Send Message</span></button>
                                            </div>
                                        </div>
                                        <!-- End Submit button -->

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="p-1-6 p-sm-1-9 p-lg-2-2 border border-radius-10 border-color-extra-light-gray bg-white h-100">
                            <h2 class="mb-3 text-capitalize h3 text-center">Our contact detail</h2>
                            <p class="mb-2-2 display-28">Write as some words about your question and we will put together your question for you inside 24 hours and tell you shortly.</p>
                            <div class="d-flex mb-4 pb-3 border-bottom border-color-extra-light-gray">
                                <div class="flex-shrink-0 mt-2">
                                    <i class="fas fa-phone-alt text-primary fs-2"></i>
                                </div>
                                <div class="flex-grow-1 ms-4">
                                    <h3 class="h5 font-weight-500">Phone Number</h3>
                                    <span class="text-muted d-block mb-1">+91 7008273406</span>

                                </div>
                            </div>
                            <div class="d-flex mb-4 pb-3 border-bottom border-color-extra-light-gray">
                                <div class="flex-shrink-0 mt-2">
                                    <i class="far fa-envelope-open text-primary fs-2"></i>
                                </div>
                                <div class="flex-grow-1 ms-4">
                                    <h3 class="h5 font-weight-500">Email Address</h3>
                                    <span class="text-muted d-block mb-1">ev@gsportsbikes.com</span>
                                    <!-- <span class="text-muted">info@domain.com</span> -->
                                </div>
                            </div>
                            <div class="d-flex mb-4 pb-3 border-bottom border-color-extra-light-gray">
                                <div class="flex-shrink-0 mt-2">
                                    <i class="fas fa-map-marker-alt text-primary fs-2"></i>
                                </div>
                                <div class="flex-grow-1 ms-4">
                                    <h3 class="h5 font-weight-500">Loaction</h3>
                                    <address class="text-muted d-block mb-0 w-md-80 w-xl-70">No - 536 cycle world Avenue, Hulimangala, Bengaluru, Karnataka 560105</address>
                                </div>
                            </div>
                            <ul class="contact-social-icon">
                                <li>
                                    <a href="#!"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div>
            <iframe class="map-h500" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d972.5832801508759!2d77.64147866963086!3d12.821737506882302!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae6b503b7490e3%3A0x7c3b260e04bb4541!2sTeam%20Cycle%20World!5e0!3m2!1sen!2sin!4v1685010931431!5m2!1sen!2sin"></iframe>
        </div>
        <!-- CONTACT INFO
        ================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.contact_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/contact.blade.php ENDPATH**/ ?>