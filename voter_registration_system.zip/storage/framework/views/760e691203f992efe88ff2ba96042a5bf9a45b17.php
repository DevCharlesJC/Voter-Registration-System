<?php $__env->startSection('content'); ?>
    <div class="container-xxl">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
          <!-- Register -->
          <div class="card">
            <div class="card-body">
              <!-- Logo -->
              <div class="app-brand justify-content-center">
                <a href="#" class="app-brand-link gap-2">
                  <img src="<?php echo url('assets/images/GsportEV_Logo.png'); ?>" width="50%" style="margin: 0 auto;"/>
                </a>
              </div>
              <!-- /Logo -->
              <h4 class="mb-2">Welcome to Gsports! 👋</h4>
              <p class="mb-4">Please sign-in to your account</p>

              <form id="formAuthentication" class="mb-3" method="POST" action="<?php echo e(route('login.perform')); ?>">
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                   <?php echo $__env->make('Backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="mb-3">
                  <label for="email" class="form-label">Email or Username</label>
                  <input type="text" class="form-control" id="email" name="username" value="<?php echo e(old('username')); ?>" placeholder="Enter your email or username" required="required" autofocus>
                  <?php if($errors->has('username')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="mb-3 form-password-toggle">
                  <!--<div class="d-flex justify-content-between">-->
                  <!--  <label class="form-label" for="password">Password</label>-->
                  <!--  <a href="#">-->
                  <!--    <small>Forgot Password?</small>-->
                  <!--  </a>-->
                  <!--</div>-->
                  <div class="input-group input-group-merge">
                    <input type="password" id="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" required="required" aria-describedby="password">
                    <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                    <?php if($errors->has('password')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="mb-3">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="remember-me" name="remember" value="1">
                    <label class="form-check-label" for="remember-me"> Remember Me </label>
                  </div>
                </div>
                <div class="mb-3">
                  <button class="btn btn-primary d-grid w-100" type="submit">Sign in</button>
                </div>
                <?php echo $__env->make('Backend.auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </form>
            </div>
          </div>
          <!-- /Register -->
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Backend/auth/login.blade.php ENDPATH**/ ?>