<!-- row 1 start -->
    <div class="row_locator">
      <div class="">
      <div class="container">
    <header class="analytic_header">
      <nav role='navigation'>
        <img src="<?php echo url('assets/images/logo.png'); ?>" alt="" class="logo_mn">
        <div id="menuToggle">
          <input type="checkbox" />
          <span></span>
          <span></span>
          <span style="margin: 0;"></span>
          <ul id="menu">
            <a href="<?php echo url('/'); ?>"><li>Home</li></a>
            <a href="<?php echo url('/aboutus'); ?>"><li>About us</li></a>
            <a href="<?php echo url('/storelocator'); ?>"><li>Locate us</li></a>
            <a href="<?php echo url('/contactus'); ?>"><li>Contact us</li></a>
            <a href="<?php echo url('/franchise'); ?>"><li>Franchise Enquire</li></a>
            <a href="<?php echo url('/career'); ?>"><li>Careers</li></a>
            <a href="<?php echo url('/investors'); ?>"><li>Investors</li></a>
          </ul>
        </div>
      </nav>
    </header>
    <div class="makitcr">
      <h2>Store Locator</h2>
      <div class="row searchbar">
        <div class="col-md-3 stn1 p-0">
         <div class="row">
          <div class="col-md-3">
            <img src="<?php echo url('assets/images/store_icon.png'); ?>" alt="">
          </div>
          <div class="col-md-9 p-0">
            <p style="margin: 0;margin-top: 3px;">Find in Store</p>
          </div>
         </div>
        </div>
        <div class="col-md-3 1input p-0">
          
            <input type="text" class="form-control boxinpt" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="State">
          
        </div>
        <div class="col-md-3 2input p-0">
         
            <input type="text" class="form-control boxinpt" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="City">
          
        </div>
        <div class="col-md-3 saerc4 p-0">
          <button type="button" class="btn btn-primary" style="padding-right: 5px;">
            <img src="<?php echo url('assets/images/search_btnmix.png'); ?>" alt="" style="width: 95%;">
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
  </div><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/layouts/partials/store_header.blade.php ENDPATH**/ ?>