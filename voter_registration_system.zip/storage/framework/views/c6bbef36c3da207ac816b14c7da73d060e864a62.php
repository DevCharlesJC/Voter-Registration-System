
<?php $__env->startSection('content'); ?>
<div class="store_display">
  <div class="container">
    <div class="outlinebox">
      <div class="row">
        <div class="col-md-4">
          <div class="card storecard">
            <img src="<?php echo url('assets/images/shop_1.jpg'); ?>" alt="">
            <h4 class="mainname">Cycle World - Gandhi Bazaar</h4>
            <p class="store_address">132, First floor, Gandhi Bazaar Main Rd Basavanagudi</p>
            <button type="button" class="btn btn-primary dirbtn">
              Get Direction
            </button>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card storecard">
            <img src="<?php echo url('assets/images/shop_2.jpg'); ?>" alt="">
            <h4 class="mainname">Cycle World - Basavanagudi</h4>
            <p class="store_address">132, First floor, Gandhi Bazaar Main Rd Basavanagudi</p>
            <button type="button" class="btn btn-primary dirbtn">
              Get Direction
            </button>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card storecard">
            <img src="<?php echo url('assets/images/shop_3.jpg'); ?>" alt="">
            <h4 class="mainname">Cycle World - Malleshwaram</h4>
            <p class="store_address">132, First floor, Gandhi Bazaar Main Rd Basavanagudi</p>
            <button type="button" class="btn btn-primary dirbtn">
              Get Direction
            </button>
          </div>
        </div>
      </div>
    </div>
    <button type="button" class="btn btn-primary viewmore_btn">
      view all
    </button>
  </div>
 </div>
  <div class="mapsec">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.716464859225!2d77.54683327517873!3d12.92593618738525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3fcd7679605d%3A0xd9b7cabcc1512799!2sCYCLE%20WORLD%20Banashankari!5e0!3m2!1sen!2sin!4v1688056521509!5m2!1sen!2sin" width="100%" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div>
  <!-- row 2 start -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.store_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/store.blade.php ENDPATH**/ ?>