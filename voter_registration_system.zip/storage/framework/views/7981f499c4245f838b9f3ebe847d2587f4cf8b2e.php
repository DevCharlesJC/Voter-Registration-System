<!-- row 1 start -->
    <div class="aboutus_row1">
      
      <div class="home_row1_cntt">
      <div class="container">
    <header class="analytic_header">
      <nav role='navigation'>
	  <a href="<?php echo url('/'); ?>">
        <img src="<?php echo url('assets/images/logo2.png'); ?>" alt="" class="logo_mn">
		</a>
        <div id="menuToggle">
          <input type="checkbox" />
          <span></span>
          <span></span>
          <span style="margin: 0;"></span>
          <ul id="menu">
            <a href="<?php echo url('/'); ?>"><li>Home</li></a>
            <a href="<?php echo url('/aboutus'); ?>"><li>About us</li></a>
            <a href="<?php echo url('/storelocator'); ?>"><li>Locate us</li></a>
            <a href="<?php echo url('/contactus'); ?>"><li>Contact us</li></a>
            <a href="<?php echo url('/franchise'); ?>"><li>Franchise Enquire</li></a>
            <a href="<?php echo url('/career'); ?>"><li>Careers</li></a>
            <a href="<?php echo url('/investors'); ?>"><li>Investors</li></a>
          </ul>
        </div>
      </nav>
    </header>
    <div class="flxftht">
        <p>At GSports EV, we believe in the power of electric scooters to transform urban transportation.<br> We offer more than just eco-friendly electric scooters - we offer a way to commute that is<br> efficient, cost-effective, and stylish.</p>
    </div>
   
  </div>
</div>
  </div>
  <!-- row 1 end --> <?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/layouts/partials/aboutus_header.blade.php ENDPATH**/ ?>