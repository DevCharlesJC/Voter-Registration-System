<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- / main menu-->
<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title"><?php echo e($Pagetitle); ?> Forms</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Form Layouts</a>
                </li>
                <li class="breadcrumb-item active"><a href="#"><?php echo e($Pagetitle); ?> Forms</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->
<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form"><?php echo e(config('global.seo')); ?></h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">						
						<form class="form">
							<div class="form-body">
								<h4 class="form-section"><i class="icon-head"></i> <?php echo e(config('global.seo')); ?></h4>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="site_title">Site Title</label>
											<input type="text" id="site_title" class="form-control" placeholder="Enter the Site Title" name="site_title">
										</div>
									</div>
								<div class="col-md-6">
										<div class="form-group">
											<label for="home_title">Home Title</label>
											<input type="text" id="home_title" class="form-control" placeholder="Enter the Home Title" name="home_title">
										</div>
									</div>									
								</div>
								<div class="form-group">
									<label for="home_title">Site Description</label>
									<div class="position-relative has-icon-left">
										<textarea id="timesheetinput7" rows="5" class="form-control" name="notes" placeholder="site description"></textarea>
										<div class="form-control-position">
											<i class="icon-file2"></i>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<label for="home_title">Keywords</label>
									<div class="position-relative has-icon-left">
										<textarea id="timesheetinput7" rows="5" class="form-control" name="notes" placeholder="site keywords"></textarea>
										<div class="form-control-position">
											<i class="icon-file2"></i>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<label for="home_title">Google Analytics</label>
									<div class="position-relative has-icon-left">
										<textarea id="timesheetinput7" rows="5" class="form-control" name="notes" placeholder="google analytics"></textarea>
										<div class="form-control-position">
											<i class="icon-file2"></i>
										</div>
									</div>
								</div>
								
								
							</div>
							<div class="form-actions">
								<button type="button" class="btn btn-warning mr-1">
									<i class="icon-cross2"></i> Cancel
								</button>
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gooesynewsportal\resources\views/Backend/seo/index.blade.php ENDPATH**/ ?>