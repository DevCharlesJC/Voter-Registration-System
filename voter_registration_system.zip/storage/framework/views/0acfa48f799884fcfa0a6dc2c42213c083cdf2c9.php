<h1>Hi, <?php echo e($uuid); ?></h1>
<p>Sending Mail from Laravel.</p><?php /**PATH C:\xampp\htdocs\voter\resources\views/emails/mail.blade.php ENDPATH**/ ?>