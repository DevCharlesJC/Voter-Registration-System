<!-- row 1 start -->
    <div class="row_1v">
	<video autoplay muted loop>
		<source src="<?php echo url('assets/images/gsportev_teaser.mp4'); ?>" type="video/mp4">
	</video>
      <div class="home_row1_cntt">
      <div class="container">
    <header class="analytic_header">
      <nav role='navigation'>
        <a href="<?php echo url('/'); ?>"><img src="<?php echo url('assets/images/logo.png'); ?>" alt="" class="logo_mn"></a>
        <div id="menuToggle">
          <input type="checkbox" />
          <span></span>
          <span></span>
          <span style="margin: 0;"></span>
          <ul id="menu">
            <a href="<?php echo url('/'); ?>"><li>Home</li></a>
            <a href="<?php echo url('/aboutus'); ?>"><li>About us</li></a>
            <a href="<?php echo url('/storelocator'); ?>"><li>Locate us</li></a>
            <a href="<?php echo url('/contactus'); ?>"><li>Contact us</li></a>
            <a href="<?php echo url('/franchise'); ?>"><li>Franchise Enquire</li></a>
            <a href="<?php echo url('/career'); ?>"><li>Careers</li></a>
            <a href="<?php echo url('/investors'); ?>"><li>Investors</li></a>
          </ul>
        </div>
      </nav>
    </header>
    <div class="row">
      <div class="col-md-12 topbnr_txt">
        <p class="txt_1">Electrifying Your Daily Commute</p>
        <p class="main-hd">India’s Most <span style="font-weight: 600;background: -webkit-linear-gradient(45deg, rgba(29,188,199,1) 0%, rgba(117,253,45,1) 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;">Reliable EV</span></p>
          <p class="cmng_soon">Is Coming Soon..</p>
        
      </div>
      <div class="enqbtn_btg">
        <!-- <a href="#" class="">ENQUIRE NOW</a> -->
        <button type="button" class="btn btn-primary enq_btn" data-toggle="modal" data-target="#exampleModalCenter">
          ENQUIRE NOW
        </button>
      </div>
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <!-- Success message -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
		  <form action="<?php echo e(route('enquiry.store')); ?>" method="post" id="enquiryform">
		  <?php echo csrf_field(); ?>
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLongTitle">ENQUIRE US</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'error' : ''); ?>" id="exampleInputEmail2" aria-describedby="emailHelp" placeholder="Name *">
					<!-- Error -->
					<?php if($errors->has('name')): ?>
					<div class="error">
						<?php echo e($errors->first('name')); ?>

					</div>
					<?php endif; ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" name="email" class="form-control <?php echo e($errors->has('email') ? 'error' : ''); ?>" id="exampleInputEmail2" aria-describedby="emailHelp" placeholder="Email Address *">
					<?php if($errors->has('email')): ?>
					<div class="error">
						<?php echo e($errors->first('email')); ?>

					</div>
					<?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" name="phoneno" class="form-control <?php echo e($errors->has('phoneno') ? 'error' : ''); ?>" id="exampleInputEmail2" aria-describedby="emailHelp" placeholder="Phone Number *" maxlength="10">
					<?php if($errors->has('phoneno')): ?>
					<div class="error">
						<?php echo e($errors->first('phoneno')); ?>

					</div>
					<?php endif; ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" name="zipcode" class="form-control <?php echo e($errors->has('zipcode') ? 'error' : ''); ?>" id="exampleInputEmail2" aria-describedby="emailHelp" placeholder="ZIP / Postal Code">
					<?php if($errors->has('zipcode')): ?>
					<div class="error">
						<?php echo e($errors->first('zipcode')); ?>

					</div>
					<?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <textarea class="form-control <?php echo e($errors->has('message') ? 'error' : ''); ?>" name="message" id="textAreaExample2" rows="4" placeholder="Message" ></textarea>
					<?php if($errors->has('message')): ?>
					<div class="error">
						<?php echo e($errors->first('message')); ?>

					</div>
					<?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="reset" class="btn btn-secondary">Reset</button>
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
  </div>
  <!-- row 1 end -->
  <div class="blank"></div><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/layouts/partials/home_header.blade.php ENDPATH**/ ?>