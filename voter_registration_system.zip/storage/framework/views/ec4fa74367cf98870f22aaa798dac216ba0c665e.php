
<?php $__env->startSection('content'); ?>
<div class="invrow_2">
    <div class="container">
      <p>The automobile industry is in the midst of a huge technological disruption. Today, electric is the preferred choice because of its inherent efficiency that will shape urban commute and the cities of tomorrow. In parallel, the world around us is getting connected, enabling integration of devices and making our life experiences seamless.</p>
    </div>
  </div>
  <!-- row 1 end -->
  <div class="blank"></div>
  <!-- row 4 start -->
  <div class="invs_row3">
    <div class="container">
      <h2>Our <span style="color: #000;">Leadership</span></h2>
      <div class="row">
        <div class="col-md-6">
          <img src="<?php echo url('assets/images/ceo_img.jpg'); ?>" alt="">
          <p class="nme_1">Krishnasamy Devaraj</p>
          <p class="nme_2">CEO</p>
        </div>
        <div class="col-md-6">
          <img src="<?php echo url('assets/images/cfo.jpg'); ?>" alt="">
          <p class="nme_1">Sabitha Krishnasamy</p>
          <p class="nme_2">CFO</p>
        </div>
      </div>
    </div>
  </div>
  <!-- row 4 end -->
  <div class="Investors_row4">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <h2>Environmental, Social & Governance</h2>
          <p>We place a strong emphasis on full-cycle sustainability in every aspect of our product lifecycle, including design, manufacturing, sourcing, end of life and battery recycling. We designed our first product, the Reliable R1, to have fewer components and a simplified assembly process, thus simplifying the manufacturing process and lowering the number of assembly steps and resources required. We source our bodywork from composites with green-to-make materials such as NONA (no-oven no autoclave)-carbon fiber composite, bio-flax composite and ocean-recycled plastic. Substantially all of our components are recyclable at the end of our product’s life, including our batteries, which can be refurbished for second use.</p>
        </div>
        <div class="col-md-3"></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.investor_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/investor.blade.php ENDPATH**/ ?>