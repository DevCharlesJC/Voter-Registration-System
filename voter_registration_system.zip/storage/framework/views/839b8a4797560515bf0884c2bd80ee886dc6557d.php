<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>GSports EV</title>
<?php echo $__env->make('Frontend.layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
  button:focus {outline: none !important;}
</style>
</head>
<body onload="hideLoader()">
<?php echo $__env->make('Frontend.layouts.partials.home_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('Frontend.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Frontend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
  function hideLoader(){
    $('.page-loader').fadeOut('slow');
  }
</script>
<script>
  $(document).ready(function() {
$('.color-choose input').on('click', function() {
    var headphonesColor = $(this).attr('data-image');

    $('.active1').removeClass('active');
    $('.left-column img[data-image = ' + headphonesColor + ']').addClass('active');
    $(this).addClass('active');
});
});
</script>
<script>
        $( document ).ready(function() {
            $('.product_red').TreeSixtyImageRotate({
                totalFrames: 23,
                endFrame: 23,
                currentFrame: 0,
                extension: ".png",
                imagesFolder: "<?php echo url('assets/images/scooter/red'); ?>/",
                smallWidth: "100%",
                smallHeight: "auto",
                largeWidth: "100%",
                largeHeight: "auto",
                imagePlaceholderClass: "images-placeholder"
            }).initTreeSixty();
            $('.product_blue').TreeSixtyImageRotate({
                totalFrames: 23,
                endFrame: 23,
                currentFrame: 0,
                extension: ".png",
                imagesFolder: "<?php echo url('assets/images/scooter/blue'); ?>/",
                smallWidth: "100%",
                smallHeight: "auto",
                largeWidth: "100%",
                largeHeight: "auto",
                imagePlaceholderClass: "images-placeholder"
            }).initTreeSixty();
            $('.product_grey').TreeSixtyImageRotate({
                totalFrames: 23,
                endFrame: 23,
                currentFrame: 0,
                extension: ".png",
                imagesFolder: "<?php echo url('assets/images/scooter/grey'); ?>/",
                smallWidth: "100%",
                smallHeight: "auto",
                largeWidth: "100%",
                largeHeight: "auto",
                imagePlaceholderClass: "images-placeholder"
            }).initTreeSixty();
            $('.product_graphite').TreeSixtyImageRotate({
                totalFrames: 23,
                endFrame: 23,
                currentFrame: 0,
                extension: ".png",
                imagesFolder: "<?php echo url('assets/images/scooter/graphite'); ?>/",
                smallWidth: "100%",
                smallHeight: "auto",
                largeWidth: "100%",
                largeHeight: "auto",
                imagePlaceholderClass: "images-placeholder"
            }).initTreeSixty();
            $('.product_white').TreeSixtyImageRotate({
                totalFrames: 23,
                endFrame: 23,
                currentFrame: 0,
                extension: ".png",
                imagesFolder: "<?php echo url('assets/images/scooter/white'); ?>/",
                smallWidth: "100%",
                smallHeight: "auto",
                largeWidth: "100%",
                largeHeight: "auto",
                imagePlaceholderClass: "images-placeholder"
            }).initTreeSixty();
            $('.product_yellow').TreeSixtyImageRotate({
                totalFrames: 23,
                endFrame: 23,
                currentFrame: 0,
                extension: ".png",
                imagesFolder: "<?php echo url('assets/images/scooter/yellow/'); ?>/",
                smallWidth: "100%",
                smallHeight: "auto",
                largeWidth: "100%",
                largeHeight: "auto",
                imagePlaceholderClass: "images-placeholder"
            }).initTreeSixty()
        });
</script>
<script>
      function redColor()
      {
        $('.mynav1').css("display" , "block");
        $('.mynav2').css("display" , "none");
        $('.mynav3').css("display" , "none");
        $('.mynav4').css("display" , "none");
        $('.mynav5').css("display" , "none");
        $('.mynav6').css("display" , "none");
        document.getElementById("redtext").innerHTML = "Red";
        document.getElementById("bluetext").innerHTML = "";
        document.getElementById("greytext").innerHTML = "";
        document.getElementById("greentext").innerHTML = "";
        document.getElementById("whitetext").innerHTML = "";
        document.getElementById("yellowtext").innerHTML = "";
      }
      function blueColor()
      {
        $('.mynav1').css("display" , "none");
        $('.mynav2').css("display" , "block");
        $('.mynav3').css("display" , "none");
        $('.mynav4').css("display" , "none");
        $('.mynav5').css("display" , "none");
        $('.mynav6').css("display" , "none");
        document.getElementById("bluetext").innerHTML = "Blue";
        document.getElementById("redtext").innerHTML = "";
        document.getElementById("greytext").innerHTML = "";
        document.getElementById("greentext").innerHTML = "";
        document.getElementById("whitetext").innerHTML = "";
        document.getElementById("yellowtext").innerHTML = "";
      }
      function greyColor()
      {
        $('.mynav1').css("display" , "none");
        $('.mynav2').css("display" , "none");
        $('.mynav3').css("display" , "block");
        $('.mynav4').css("display" , "none");
        $('.mynav5').css("display" , "none");
        $('.mynav6').css("display" , "none");
        document.getElementById("greytext").innerHTML = "Grey";
        document.getElementById("bluetext").innerHTML = "";
        document.getElementById("redtext").innerHTML = "";
        document.getElementById("greentext").innerHTML = "";
        document.getElementById("whitetext").innerHTML = "";
        document.getElementById("yellowtext").innerHTML = "";
      }

      function greenColor()
      {
        $('.mynav1').css("display" , "none");
        $('.mynav2').css("display" , "none");
        $('.mynav3').css("display" , "none");
        $('.mynav4').css("display" , "block");
        $('.mynav5').css("display" , "none");
        $('.mynav6').css("display" , "none");
        document.getElementById("greentext").innerHTML = "Graphite";
        document.getElementById("bluetext").innerHTML = "";
        document.getElementById("redtext").innerHTML = "";
        document.getElementById("greytext").innerHTML = "";
        document.getElementById("whitetext").innerHTML = "";
        document.getElementById("yellowtext").innerHTML = "";
      }

      function whiteColor()
      {
        $('.mynav1').css("display" , "none");
        $('.mynav2').css("display" , "none");
        $('.mynav3').css("display" , "none");
        $('.mynav4').css("display" , "none");
        $('.mynav5').css("display" , "block");
        $('.mynav6').css("display" , "none");
        document.getElementById("whitetext").innerHTML = "White";
        document.getElementById("bluetext").innerHTML = "";
        document.getElementById("redtext").innerHTML = "";
        document.getElementById("greentext").innerHTML = "";
        document.getElementById("greytext").innerHTML = "";
        document.getElementById("yellowtext").innerHTML = "";
      }

      function yellowColor()
      {
        $('.mynav1').css("display" , "none");
        $('.mynav2').css("display" , "none");
        $('.mynav3').css("display" , "none");
        $('.mynav4').css("display" , "none");
        $('.mynav5').css("display" , "none");
        $('.mynav6').css("display" , "block");
        document.getElementById("yellowtext").innerHTML = "Yellow";
        document.getElementById("bluetext").innerHTML = "";
        document.getElementById("redtext").innerHTML = "";
        document.getElementById("greentext").innerHTML = "";
        document.getElementById("greytext").innerHTML = "";
        document.getElementById("whitetext").innerHTML = "";

      }
</script>
<script>
  var btn = $('#button');
$(window).scroll(function() {
  if ($(window).scrollTop() > 300) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});
btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '300');
});
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/layouts/home_master.blade.php ENDPATH**/ ?>