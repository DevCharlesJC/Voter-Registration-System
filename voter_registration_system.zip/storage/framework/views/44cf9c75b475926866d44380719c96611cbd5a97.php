<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- / main menu-->

    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><!-- stats -->
<div class="row">
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                            <h3 class="pink"><?php echo e(count($getVoters)); ?></h3>
                            <span>Total Voters Count</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-bag2 pink font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                            <h3 class="teal"><?php echo e(count($todayVoters)); ?></h3>
                            <span>Today Register Count</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-user1 teal font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                            <h3 class="deep-orange"><?php echo e(count($attendVoters)); ?></h3>
                            <span>Attend Count</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-diagram deep-orange font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--/ stats -->
<!-- Recent invoice with Statistics -->
<div class="row match-height">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Recent Voter Details</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>#Sno</th>
								<th>UUID</th>
                                <th>Name</th>
								<th>Date of Birth</th>
								<th>District</th>
								<th>State</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
						
						<?php 
						if(count($getVoters) !=0){
						$i = 1;
						foreach($Data as $Row)
						{
						if($Row->status == 0)
						{
						$data = 'Active';
						}
						else
						{
						$data = 'Deactive';
						}
						?>
                            <tr>
                                <td class="text-truncate"><a href="#"><?php echo e($i); ?></a></td>
                                <td class="text-truncate"><?php echo e($Row->id); ?></td>
								<td class="text-truncate"><?php echo e(ucfirst($Row->firstname. ' '. $Row->lastname)); ?></td>
								<td class="text-truncate"><?php echo e(date("m-d-Y", strtotime($Row->dob))); ?></td>
								<td class="text-truncate"><?php echo e(ucfirst($Row->district)); ?></td>
								<td class="text-truncate"><?php echo e(ucfirst($Row->state)); ?></td>
                                <td class="text-truncate"><span class="tag tag-default tag-success"><?php echo e($data); ?></span></td>
								
						<?php 
						$i++; 
						} 
						?>
                            </tr>
						<?php 
						} 
						else 
						{
						?>
							<tr>
								<td colspan="7">
									<h3 style="text-align: center;font-size: 15px;line-height: 30px;color: red;">No Data Found!..</h3>
								</td>
							</tr>
						<?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\voter\resources\views/Backend/home/index.blade.php ENDPATH**/ ?>