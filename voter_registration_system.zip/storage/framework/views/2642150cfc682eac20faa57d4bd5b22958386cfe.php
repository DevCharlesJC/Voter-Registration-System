
<?php $__env->startSection('content'); ?>
<!-- row 4 start -->
  <div class="r1_row2">
    <div class="container">
      <div class="row">
        <div class="col-md-5 p-0 bgclr_bck2">
          <h2>Performance</h2>
          <div class="row">
            <div class="col-md-6">
              <div class="st-inr2">
                <img src="<?php echo url('assets/images/01.png'); ?>" alt="">
                <p><b>Motor</b><br>
                  2.5kw
                  </p>
              </div>
              <div class="st-inr2">
                <img src="<?php echo url('assets/images/02.png'); ?>" alt="">
                <p><b>Battery</b><br>
                  4000 Watts
                  </p>
              </div>
              <div class="st-inr2">
                <img src="<?php echo url('assets/images/03.png'); ?>" alt="">
                <p><b>Range per charge</b><br>
                  100km
                  </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="st-inr2">
                <img src="<?php echo url('assets/images/04.png'); ?>" alt="">
                <p><b>Top speed</b><br>
                  85 kmph                  
                  </p>
              </div>
              <div class="st-inr2">
                <img src="<?php echo url('assets/images/05.png'); ?>" alt="">
                <p><b>Cluster</b><br>
                  7 Inch
                  </p>
              </div>
              <div class="st-inr2">
                <img src="<?php echo url('assets/images/06.png'); ?>" alt="">
                <p><b>Charging time</b><br>
                  2hrs
                  </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-7 p-0">
          <img src="<?php echo url('assets/images/perf_img.jpg'); ?>" alt="" style="width:100%;">
        </div>
      </div>
    </div>
  </div>
  <!-- row 4 end -->
  <!-- row 2 start -->
  <div class="r1row_3">
    <div class="container">      
      <div class="row setheightrw">
        <div class="col-md-5">
          <div class="row">
            <div class="col-md-12">
              <h2>cluster</h2>
      <p class="inr_pd">The cluster incorporates a touch sensor that provides effortless accessibility to its features. It also includes an Android , designed to simplify usage and enhance user experience by enabling easy navigation and interaction.</p>
              <div class="row">
                <div class="col-md-6">
                  <div class="st-inr">
                    <img src="<?php echo url('assets/images/icon_1.png'); ?>" alt="">
                    <p><b>Display Type</b><br>
                      7-inch TFT Smart Display
                      </p>
                  </div>
                  <div class="st-inr">
                    <img src="<?php echo url('assets/images/icon_2.png'); ?>" alt="">
                    <p><b>Interface</b><br>
                      Android
                      </p>
                  </div>
                  <div class="st-inr">
                    <img src="<?php echo url('assets/images/icon_3.png'); ?>" alt="">
                    <p><b>Incoming Call Alerts</b><br>
                      Enabled
                      </p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="st-inr">
                    <img src="<?php echo url('assets/images/icon_4.png'); ?>" alt="">
                    <p><b>Side Stand Indication</b><br>
                      Enabled                  
                      </p>
                  </div>
                  <div class="st-inr">
                    <img src="<?php echo url('assets/images/icon_5.png'); ?>" alt="">
                    <p><b>Battery Level Indication</b><br>
                      Enabled
                      </p>
                  </div>
                  <div class="st-inr">
                    <img src="<?php echo url('assets/images/icon_6.png'); ?>" alt="">
                    <p><b>DTE (Distance To Empty)</b><br>
                      Enabled
                      </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-7">
          <img src="<?php echo url('assets/images/newclusbik.png'); ?>" alt="" class="bkc">
        </div>
      </div>
    </div>
  </div>
  <!-- row 2 end -->
  <div class="blank"></div>
  <!-- row 3 start -->
  <!-- row 5 start -->
  <div class="r1row4">
    <div class="container">
      <div class="row">
        <div class="col-md-6 p-0">
          <img src="<?php echo url('assets/images/battery_img.jpg'); ?>" alt="" style="width: 100%;">
        </div>
        <div class="col-md-6 p-0 bxkcnt">
            <h2>Battery</h2>
          <p>The battery comes with an IP67 rating, ensuring its durability and resistance to dust and water. Additionally, our engineers have incorporated advanced thermal management techniques, compliant with AIS standards, into the battery's design. Rest assured, the battery is backed by a comprehensive 3-year warranty.
          </div>
          </p>
      </div>
    </div>
  </div>
  <!-- row 5 end -->
  <div class="blank"></div>
  <!-- row 6 start -->
    <div class="r1row5">
      <div class="container">
        <h2>chassis</h2>
        <p>The chassis is engineered with a rigid, strong, and aerodynamic tubular structure, offering enhanced stability and performance. It features a telescopic suspension system at the front and a hydraulic mono suspension at the rear, ensuring a smooth and comfortable ride. With a ground clearance of 165mm, the vehicle maintains ample distance from the road surface, allowing for confident maneuverability on various terrains.</p>
        <img src="<?php echo url('assets/images/chassispng.png'); ?>" alt="" class="nononsim chassisaltr">
        <div class="chassi_bg">
          <div class="row gtyt">
            <div class="col-md-4">
              <ul>
                <li><b>Frame Type</b></br> 
                  Tubular structure
               </li>
               <li><b>Front suspension</b></br> 
                Telescopic Suspension
            </li>
              </ul>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-4">
              <ul>
                <li><b>Rear suspension</b></br> 
                  Hydraulic Mono Suspension
               </li>
               <li><b>Ground Clearance</b></br> 
                165 mm
            </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  <!-- row 6 end -->
  <div class="blank"></div>
  <!-- row 8 start -->
  <div class="r1r0w6">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="card" style="border: 0;">
            <h2>brakes</h2>
            <img src="<?php echo url('assets/images/brk_infoimg.jpg'); ?>" alt="">
            <div class="inftabr">
              <p>we have opted for a reliable and efficient disc brake setup. This choice ensures excellent stopping power and responsive braking performance, providing enhanced safety and control.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card" style="border: 0;">
            <h2>lighting</h2>
            <img src="<?php echo url('assets/images/liginfoimg.jpg'); ?>" alt="">
            <div class="inftabr">
              <p>The LED lighting system is designed with high focus and clarity, offering superior illumination. It not only provides enhanced visibility but also consumes minimal energy, resulting in efficient energy consumption and reduced power consumption.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card" style="border: 0;">
            <h2>tyres</h2>
            <img src="<?php echo url('assets/images/tyrinfoimg.jpg'); ?>" alt="">
            <div class="inftabr">
              <p>Experience superior traction and durability with our high-quality tires. Designed for various terrains, our tires provide optimal performance and control during your rides. Choose from our wide selection of reliable tire options to enhance your cycling adventures. Elevate your ride with our premium tires today.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>
  <!-- row 8 end -->
  <div class="blank"></div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.product_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/product.blade.php ENDPATH**/ ?>