<?php $__env->startSection('content'); ?>
<!-- row 2 start -->
  <div class="row_2">
    <img src="<?php echo url('assets/images/mobbikebg.jpg'); ?>" alt="" class="nona-1">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          
        </div>
        <div class="col-md-6">
          <div class="white_box">
            <h2>Embark on a thrilling electric journey with our state-of-the-art EV scooter, equipped with a powerful hub motor for an unmatched ride</h2>
              <p>Step into a world of electric liberation, where range and charging anxieties vanish into thin air
              </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- row 2 end -->
  <div class="blank"></div>
  <!-- row 3 start -->
  <div class="row_3">
    <div class="container">      
      <div class="row changitd">
        <div class="col-md-6 lftprt">
          <div class="row comb_pts batterypt">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/battery_icon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">4 kWh Battery</p>
              <p class="pts_p">With a peak power of 12 KW</p>
              <span class="custom critical">
                <p>The battery comes with an IP67
                  rating, ensuring its durability and
                  resistance to dust and water.
                  Additionally, our engineers have
                  incorporated advanced thermal
                  management techniques,
                  compliant with AIS standards,
                  into the battery's design. Rest
                  assured, the battery is backed by
                  a comprehensive 3-year warranty.</p>
              </span>
              </a>
            </div>
          </div>
          <div class="row comb_pts chargerpt">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/charger_icon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">Portable Charger</p>
              <p class="pts_p">Easy and Fast Charging</p>
              <span class="custom critical">
                <p>Introducing our portable charger, designed to efficiently charge your devices from 0% to 80% in just 4 hours. With its high capacity, output power, and built-in safety features, it's the perfect companion for on-the-go charging.</p>
              </span>
            </a>
            </div>
          </div>
          <div class="row comb_pts motorpt">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/hubmotor_icon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">2.5 kWh Hub Motor</p>
              <p class="pts_p">Higher Torque, Better Traction,<br> Reduces maintenance cost</p>
              <span class="custom critical">
                <p>The motor boasts an impressive
                  IP67 rating, ensuring its durability
                  and resilience against dust and
                  water. It is equipped with
                  regenerative braking capabilities,
                  allowing for the efficient recapture
                  of energy during braking
                  maneuvers. Moreover, this motor
                  delivers a substantial torque output,
                  providing robust performance and
                  power.</p>
              </span>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 ritprt">
          <div class="row comb_pts aipt">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/ai_icon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">Integrated AI</p>
              <p class="pts_p">Improved efficiency, safety<br> and ease of use.</p>
              <span class="custom critical">
                <p>The cluster incorporates a touch
                  sensor that provides effortless
                  accessibility to its features. It also
                  includes an Android , designed to
                  simplify usage and enhance user
                  experience by enabling easy
                  navigation and interaction</p>
              </span>
              </a>
            </div>
          </div>
          <div class="row comb_pts ledpt">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/led_icon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">LED Headlight</p>
              <p class="pts_p">Shockproof, vibration-resistant,<br> and energy-efficient.</p>
              <span class="custom critical">
                <p>The LED lighting system is
                  designed with high focus and
                  clarity, offering superior
                  illumination. It not only provides
                  enhanced visibility but also
                  consumes minimal energy,
                  resulting in efficient energy
                  consumption and reduced power
                  consumption</p>
              </span>
              </a>
            </div>
          </div>
          <div class="row comb_pts sleekpt">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/discicon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">Front Disc</p>
              <p class="pts_p">220mm</p>
              <span class="custom critical disc_dec">
                <p>Introducing our 220mm front disk brake, designed to provide optimal braking performance for your ride. With its precise engineering and durable construction, our disk brake offers superior stopping power and improved heat dissipation.</p>
              </span>
              </a>
            </div>
          </div>
          <div class="row comb_pts suspensionpt" data-mdb-toggle="popover"
          title="Popover title"
          data-mdb-content="And here's some amazing content. It's very engaging. Right?"
          data-mdb-trigger="hover">
            <div class="pts_img">
              <img src="<?php echo url('assets/images/suspension_icon.png'); ?>" alt="">
            </div>
            <div>
              <a class="tooltip" href="#">
              <p class="pts_hd">Mono Shock Suspension</p>
              <p class="pts_p">Offers better handling and stability</p>
              <span class="custom critical last_tooltip">
                <p>The use of a single shock means using a single valve, which exerts pressure equally unlike twin shocks. To add to this, the piston in a monoshock is much wider than the one found on twin-shock absorbers. In effect, monoshocks offer better and more precise damping, which results in better handling and stability.</p>
              </span>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="mobfea_cnt">
        <div class="rowf">
          <div class="icon_f">
            <img src="<?php echo url('assets/images/battery_icon.png'); ?>" alt="">
          </div>
          <div class="ctn_f">
            <p class="pts_hd">4.8 kWh Battery</p>
            <p class="pts_p">With a peak power of 7KW</p>
          </div>
        </div>
        <div class="rowf">
          <div class="icon_f">
            <img src="<?php echo url('assets/images/charger_icon.png'); ?>" alt="">
          </div>
          <div class="ctn_f">
            <p class="pts_hd">Portable Charger</p>
            <p class="pts_p">Easy and Fast Charging</p>
          </div>
        </div>
        <div class="rowf">
          <div class="icon_f">
            <img src="<?php echo url('assets/images/hubmotor_icon.png'); ?>" alt="">
          </div>
          <div class="ctn_f">
            <p class="pts_hd">3 kWh Hub Motor</p>
            <p class="pts_p">Higher Torque, Better Traction,<br> Reduces maintenance cost</p>
          </div>
        </div>
        <div class="rowf">
          <div class="icon_f">
            <img src="<?php echo url('assets/images/ai_icon.png'); ?>" alt="">
          </div>
          <div class="ctn_f">
            <p class="pts_hd">Integrated AI</p>
              <p class="pts_p">Improved efficiency, safety<br> and ease of use.</p>
          </div>
        </div>
        <div class="rowf">
          <div class="icon_f">
            <img src="<?php echo url('assets/images/led_icon.png'); ?>" alt="">
          </div>
          <div class="ctn_f">
            <p class="pts_hd">LED Headlight</p>
              <p class="pts_p">shockproof, vibration-resistant,<br> and energy-efficient.</p>
          </div>
        </div>
        <div class="rowf">
          <div class="icon_f">
            <img src="<?php echo url('assets/images/discicon.png'); ?>" alt="">
          </div>
          <div class="ctn_f">
            <p class="pts_hd">Front Disc</p>
            <p class="pts_p">220mm</p>
          </div>
        </div>
        
      </div>
    </div>
  </div>
  <!-- row 3 end -->
  <!-- row 4 start -->
  <div class="row_4">
    <div class="container">
      <div class="row">
        <div class="col-md-5 p-0 bgclr_bck">
          <h2>Smart<br> 
            Technology</h2>
          <div class="row">
            <div class="col-md-6">
              <img src="<?php echo url('assets/images/display_cluster.jpg'); ?>" alt="" style="width:100%;" class="cluston">
              <div class="st-inr">
                <img src="images/icon_1.png" alt="">
                <p><b>Display Type</b><br>
                  7-inch TFT Smart Display
                  </p>
              </div>
              <div class="st-inr">
                <img src="<?php echo url('assets/images/icon_2.png'); ?>" alt="">
                <p><b>Interface</b><br>
                  Android
                  </p>
              </div>
              <div class="st-inr">
                <img src="<?php echo url('assets/images/icon_3.png'); ?>" alt="">
                <p><b>Incoming Call Alerts</b><br>
                  Enabled
                  </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="st-inr">
                <img src="<?php echo url('assets/images/icon_4.png'); ?>" alt="">
                <p><b>Side Stand Indication</b><br>
                  Enabled                  
                  </p>
              </div>
              <div class="st-inr">
                <img src="<?php echo url('assets/images/icon_5.png'); ?>" alt="">
                <p><b>Battery Level Indication</b><br>
                  Enabled
                  </p>
              </div>
              <div class="st-inr">
                <img src="<?php echo url('assets/images/icon_6.png'); ?>" alt="">
                <p style="margin: 0;"><b>DTE (Distance To Empty)</b><br>
                  Enabled
                  </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-7 p-0">
          <img src="<?php echo url('assets/images/display_cluster.jpg'); ?>" alt="" style="width:100%;" class="clustnone">
        </div>
      </div>
    </div>
  </div>
  <!-- row 4 end -->
  <div class="blank"></div>
  <!-- row 5 start -->
  <div class="row_5">
    <img src="<?php echo url('assets/images/bikeprice_bg1.jpg'); ?>" alt="" class="nona-1">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          
        </div>
        <div class="col-md-8 valnbt">
          <div class="white_bgp">
            <div class="row">
              <div class="col-md-8">
                <div class="row">
                  <div class="col-md-4">
                    <p style="margin: 0;" class="spdmnttx">80 <span class="spnctr">kmph</span></p>
                    <p style="margin: 0;" class="btmtxtsp">Top speed</p>
                  </div>
                  <div class="col-md-4 bdrlrpx">
                    <p style="margin: 0;" class="spdmnttx">140 <span class="spnctr">km</span></p>
                    <p style="margin: 0;" class="btmtxtsp">Certified range</p>
                  </div>
                  <div class="col-md-4">
                    <p style="margin: 0;" class="spdmnttx">4 <span class="spnctr">kWh</span></p>
                    <p style="margin: 0;" class="btmtxtsp">Battery</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <a href="<?php echo url('product_R1'); ?>">
                  <button class="expn_bg">Explore Now</button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- row 5 end -->
  <div class="blank"></div>
  <!-- row 6 start -->
    <div class="row_6">
      <div class="container">
        <h1>0 to wowww <span style="color: #9eb0bd;">in 3.5 sec</span></h1>
        <div class="perf_box">
          <div class="row">
            <div class="col-md-3">
              <div class="per_inr_sep">
                <p style="font-weight: bold;">Top Speed</p>
                <p style="font-weight: 100;" class="spb">80 km/h</p>
              </div>
            </div>
            <div class="col-md-3">
              <div class="per_inr_sep">
                <p style="font-weight: bold;">Acceleration</p>
                <p style="font-weight: 100;" class="spb">0-40km/h in 3.5 sec</p>
              </div>
            </div>
            <div class="col-md-3">
              <div class="per_inr_sep">
                <p style="font-weight: bold;">Riding Mode</p>
                <p style="font-weight: 100;" class="spb">Eco | Sports</p>
              </div>
            </div>
            <div class="col-md-3">
              <div class="">
                <p style="font-weight: bold;">Gradeability</p>
                <p style="font-weight: 100;" class="">18 deg</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <!-- row 6 end -->
  <div class="blank"></div>
  <!-- row 7 start -->
  <div class="row_7">
    <div class="container">
      
      
      <div class="row">
        <div class="col-md-12 left-column">          
          
           <div class="target_red threesixty-image-rotate product_red mynav1" style="display: block;">
          </div>
          <div class="target_blue threesixty-image-rotate product_blue mynav2" style="display: none;">
          </div>
          <div class="target_grey threesixty-image-rotate product_grey mynav3" style="display: none;">
          </div>
          <div class="target_green threesixty-image-rotate product_graphite mynav4" style="display: none;">
          </div>
          <div class="target_white threesixty-image-rotate product_white mynav5" style="display: none;">
          </div>
          <div class="target_yellow threesixty-image-rotate product_yellow mynav6" style="display: none;">
          </div>           
        </div>
        <div class="col-md-12">
          <div class="product-configuration">
            
          <!-- Product Color -->
          <div class="product-color">
            <h1>Available Colors</h1>
            <div class="color-choose">
              <div class="col-md-12 makflx">
                
                <div class="row spc_btw">
                  
                  <div class="col-md-12 p-0 makfxd">
                  <input data-image="red" type="radio" id="red" name="color" value="red" checked onclick="redColor()">
                  <label for="red"><span></span></label>
                  </div>
                  <div class="col-md-12 p-0 makfxd">
                    <p class="color-text" id="redtext">Red</p>
                  </div>
                </div>
                <div class="row spc_btw">
                 
                  <div class="col-md-12 p-0 makfxd">
                  <input data-image="blue" type="radio" id="blue" name="color" value="blue" onclick="blueColor()">
                  <label for="blue"><span></span></label>
                  </div>
                  <div class="col-md-12 p-0 makfxd">
                    <p class="color-text" id="bluetext">&nbsp;</p>
                    </div>
                </div>
                <div class="row  spc_btw">
                  
                  <div class="col-md-12 p-0 makfxd">
                  <input data-image="grey" type="radio" id="grey" name="color" value="grey" onclick="greyColor()">
                  <label for="grey"><span></span></label>
                  </div>
                  <div class="col-md-12 p-0 makfxd">
                    <p class="color-text" id="greytext">&nbsp;</p>
                    </div>
                </div>
                <div class="row  spc_btw">
                  
                  <div class="col-md-12 p-0 makfxd">
                  <input data-image="green" type="radio" id="green" name="color" value="green" onclick="greenColor()">
                  <label for="green"><span></span></label>
                  </div>
                  <div class="col-md-12 p-0 makfxd">
                    <p class="color-text" id="greentext">&nbsp;</p>
                    </div>
                </div>
                <div class="row  spc_btw">
                  
                  <div class="col-md-12 p-0 makfxd">
                  <input data-image="white" type="radio" id="white" name="color" value="white" onclick="whiteColor()">
                  <label for="white"><span></span></label>
                  </div>
                  <div class="col-md-12 p-0 makfxd">
                    <p class="color-text" id="whitetext">&nbsp;</p>
                    </div>
                </div>
                <div class="row  spc_btw">
                 
                  <div class="col-md-12 p-0 makfxd">
                  <input data-image="yellow" type="radio" id="yellow" name="color" value="yellow" onclick="yellowColor()">
                  <label for="yellow"><span></span></label>
                  </div>
                  <div class="col-md-12 p-0 makfxd">
                    <p class="color-text" id="yellowtext">&nbsp;</p>
                    </div>
                </div>
              </div>
              
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
  <!-- row 7 end -->
  <div class="blank"></div>
  <!-- row 8 start -->
  <div class="row_8">
    <div class="container">
      <h1 class="odts">Other <span style="color: #000;">details</span></h1>
      <div class="row">
        <div class="col-md-6">
          <div class="img_contar">
            <img src="<?php echo url('assets/images/od_chassis.jpg'); ?>" alt="" style="width: 100%;" class="imgodd">
            <div class="overlay">
              <div class="ovrtext">
                <ul>
                  <li><b>Frame Type</b> - <span class="thn_txt">Tubular Structure</span></li>
                  <li><b>Front Suspension</b> - <span class="thn_txt">Telescopic Suspension</span></li>
                  <li><b>Rear Suspension</b> - <span class="thn_txt">Hydraulic Mono Suspension</span></li>
                  <li><b>Ground Clearance</b> - <span class="thn_txt">165mm</span></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="img_contar">
            <img src="<?php echo url('assets/images/od_brakes.jpg'); ?>" alt="" style="width: 100%;height: 345px;" class="imgodd">
            <div class="overlay">
              <div class="ovrtext">
                <ul>
                  <li><b>Rear Brake Size</b> - <span class="thn_txt">180mm</span></li>
                  <li><b>Front Brake Size</b> - <span class="thn_txt">220mm</span></li>
                  <li><b>Rear / Front Brake type</b> - <span class="thn_txt">Disc Brake</span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 makspc">
          <div class="img_contar">
            <img src="<?php echo url('assets/images/od_lighiting.jpg'); ?>" alt="" style="width: 100%;" class="imgodd">
            <div class="overlay">
              <div class="ovrtext">
                <ul>
                  <li><b>Head Lamp/Tail Lamp</b> - <span class="thn_txt">LED</span></li>
                  <li><b>Number Plate Lamp</b> - <span class="thn_txt">LED</span></li>
                  <li><b>Signature Position Lamp</b> - <span class="thn_txt">LED</span></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="img_contar">
            <img src="<?php echo url('assets/images/od_cluster.jpg'); ?>" alt="" style="width: 100%;" class="imgodd">
            <div class="overlay">
              <div class="ovrtext">
                <ul>
                  <li><b>Size</b> - <span class="thn_txt"> 7 inch</span></li>
                  <li><b>Resolution</b> - <span class="thn_txt">1024 × 600 PPI</span></li>
                  <li><b>Brightness</b> - <span class="thn_txt">1000 Lux</span></li>
                  <li><b>User Interface</b> - <span class="thn_txt">Android</span></li>
                  <li><b>Touch Screen</b> - <span class="thn_txt">Yes</span></li>
                  <li><b>Bluetooth</b> - <span class="thn_txt">Via Mobile App</span></li>
                  <li><b>GSM/GPS</b> - <span class="thn_txt">Yes</span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
  <!-- row 8 end -->
  <div class="blank"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.home_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/home.blade.php ENDPATH**/ ?>