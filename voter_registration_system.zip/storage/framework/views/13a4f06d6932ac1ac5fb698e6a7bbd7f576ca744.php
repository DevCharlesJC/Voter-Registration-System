
<?php $__env->startSection('content'); ?>
<div class="career_row2">
    <div class="container">
      <h2>why you should <span style="color: #000;">join us</span></h2>
      <p class="styp">
              At Gports Bikes, we thrive on innovation and boldly venture into
      uncharted territories to create groundbreaking products. Our relentless
      pursuit of excellence has led us to pioneer new market segments, setting
      the stage for unparalleled success. We place utmost importance on our
      customers, striving to surpass their expectations and consistently create
      moments of sheer delight.
      </p>
      <p class="styp">The essence of Gports Bikes lies in our unwavering commitment to quality.
        It is the very core of our DNA, permeating every aspect of our operations.
        We believe in nurturing and empowering our talented workforce, providing
        them with the tools and motivation needed to unleash their full potential.
        Embracing diversity is not just a value we uphold; it is the driving force
        behind our culture of innovation and collaboration. We actively encourage
        ideation and foster an environment where every voice is valued and
        celebrated.</p>
    </div>
  </div>
  <div class="ctrbg">
    <div class="ctrbg_inr">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <p>We recognize that the key to sustained success lies in continuous growth and development. Hence, we invest in our employees, providing them with opportunities for up-skilling and honing their expertise. By nurturing their talents, we fuel our collective progress and solidify our position as industry leaders.</p>
                </div>
                <div class="col-md-6">
                    <img src="<?php echo url('assets/images/peoplec_bg.jpg'); ?>" alt="" class="cntrimgfx">
                    <img src="<?php echo url('assets/images/peoplepng.png'); ?>" alt="" class="nononsim">
                </div>
                <div class="col-md-3">
                    <p>At Gports Bikes, we boldly embrace change and welcome the challenges it brings. We remain steadfast in our pursuit of progress, staying ahead of the curve and seizing opportunities that arise. Our passion for innovation knows no bounds, propelling us to push the boundaries of what is possible.</p>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="careerlst_rw">
    <div class="container">
        <p>Join us at Gports Bikes as we embark on an extraordinary journey of growth and transformation. Together, we will shape the future of the biking industry, leaving an indelible mark on the world.</p>
    </div>
  </div>
  <section>
    <div class="container">
        <h2 class="aval_jbs">available  <span style="color: #000;">jobs</span></h2>
        <div class="row justify-content-center mt-n1-9 recent-job-style2 btmspc">
            <div class="col-lg-10 mt-1-9">
                <div class="p-1-6 border border-color-extra-light-gray bg-white border-radius-10">
                    <div class="d-lg-flex justify-content-between align-items-center text-center text-lg-start">
                        <div class="d-lg-flex align-items-center mb-4 mb-lg-0">
                            
                            <div class="flex-grow-1 ms-lg-4">
                                <h4 class="h5"><a href="career_2.html">Assistant Manager</a></h4>
                                <span class="me-2"><i class="ti-briefcase pe-2 text-secondary"></i>Finance Agency</span>
                                <span class="me-2"><i class="ti-location-pin pe-2 text-secondary"></i>Canada</span>
                                <span class="me-2"><i class="ti-time pe-2 text-secondary"></i>08 Hour Ago</span>
                                <span class="me-2"><i class="far fa-money-bill-alt pe-2 text-secondary"></i>$25K</span>
                                <span class="company-info radius-10">Full Time</span>
                            </div>
                        </div>
                        <a href="<?php echo url('career_details'); ?>" class="butn butn-md">Apply Job</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- row 8 end -->
<div class="blank"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.career_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/career.blade.php ENDPATH**/ ?>