
<?php $__env->startSection('content'); ?>
<div class="franrow_2">
    <div class="container">
      <h2>Request a <span style="color: #000;">Call Back</span></h2>
      <form>
      <div class="form_box">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name *">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email Address *">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Phone Number *">
            </div>
          </div>
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-6">
                <small id="emailHelp" class="form-text text-muted">Do you have a retail property ?</small>
              </div>
              <div class="col-md-6">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                  <label class="form-check-label" for="inlineRadio1">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                  <label class="form-check-label" for="inlineRadio2">No</label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Address">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ZIP / Postal Code">
            </div>
          </div>
          <div class="col-md-6">
          
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <textarea class="form-control" id="textAreaExample1" rows="4" placeholder="Message"></textarea>
            </div>
            <div class="form-group">
              <button class="btn msgbtn" type="submit">Send Message</button>
            </div>
          </div>
          
          
        </div>
      </div>
    </form>
    </div>
  </div>
  <!-- row 1 end -->
  <div class="blank"></div>
  <!-- row 4 start -->
  <div class="franchises_row3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>Business <span style="color: #000;">Setup Process</span></h2>
          <p>Step 1 - Franchisee Interview<br>
            Step 2 – Business Plan & Support Presentation & Discussion<br>
            Step 3 – Location Zero In<br>
            Step 4 – GSportsEv Official Visit, Inspection and Market Research<br>
            Step 5 – Franchisee Visit to GSportsEv, Head Office. (Bengaluru, Karnataka, India)<br>
            Step 6 – Franchise Agreement<br>
            Step 7 – Store Legalities<br>
            Step 8 – Store Interiors & Branding<br>
            Step 9 – Stock Planning<br>
            Step 10 – Training of Franchise Personnel<br>
            Step 11 – Marketing Drive Both ATL & BTL (Minimum 10 days & Race / Ride conducted as required)<br>
            Step 12 – Open For Business<br>
            Step 13 – Constant follow up and upgrade</p>
        </div>
        <div class="col-md-6 imgcap">
          <img src="<?php echo url('assets/images/qx.png'); ?>" alt="" width="100%">
        </div>
      </div>
    </div>
  </div>
  <!-- row 4 end -->
  <div class="franchises_row4">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <img src="<?php echo url('assets/images/inversment_img.jpg'); ?>" alt=""  class="invimg">
        </div>
        <div class="col-md-6 spxlftg">
          <h2><span style="color: #000;">Investment</span> Details</h2>
          <ul style="padding-left: 20px;">
            <li>The investment required for a Franchise setup is up to 25 – 30 Lakhs depending on Store location, Ownership, and city of business.</li>
            <li>The Net Profit of a minimum of 5% of Investment per month is being achieved year after year by all Team Cycle World, Franchises.</li>
            <li>A Break-Even is easily achievable within 20 Months of Business and a minimum 10% growth in the Market per annum is achieved. The Customer base & Demand of the cycle industry is growing at Minimum 15% per annum.</li>
            <li>The business arena is open with fewer competitors and unlimited customer opportunity as, in last 4 years the Customer age group from Age 3 to Age 16 and rarely above age 30, has evolved to •  Age 3 to Age 70, our oldest customer being so.</li>
            <li>There is a huge boom in sales in the Age 30 to Age 45 category and increasing every day</li>
            <li>We are glad to offer all our expertise and knowledge gathered over the last decade in the cycle industry and share our name & brand with you to build a better Indian Bicycle Market, provide more opportunities, definitely reduce pollution point by point and promote a healthy sustainable Life Style.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- row 2 start -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.franchise_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gsports\resources\views/Frontend/franchise.blade.php ENDPATH**/ ?>