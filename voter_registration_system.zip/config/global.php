<?php

return [
  'dashboard' => 'Dashboard',
  'voter' => 'Voter',
  'addvoter' => 'Add Voter',
  'viewvoter' => 'View Voter',
  'reports' => 'Reports',
  
];