<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVoterTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('voter', function (Blueprint $table) {
            $table->voter_id();
			$table->string('firstname')->nullable();
			$table->string('lastname')->nullable();
			$table->date('dob')();
			$table->string('email')->unique();
			$table->string('mobile')->nullable();
			$table->string('state')->nullable();
			$table->string('district')->nullable();			
			$table->string('taluk')->nullable();
			$table->string('address')->nullable();
			$table->string('id');
			$table->string('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('voter');
    }
}
